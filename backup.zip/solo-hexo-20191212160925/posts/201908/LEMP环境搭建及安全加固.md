title: LEMP环境搭建及安全加固
date: '2019-08-02 17:46:34'
updated: '2019-11-29 16:35:12'
tags: [安全加固, 搭建环境]
permalink: /articles/2019/08/02/1575014353213.html
---
![](https://img.hacpai.com/bing/20180201.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

![](https://img.hacpai.com/bing/20191010.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 基于linux的LEMP（Linux，Nginx，MySQL，PHP）环境搭建
这个学期忙于搞大创项目和考试，好久没有学习安全方面的知识。本来自己有打算去学re，但是偶然的机会能在“信安之路”大佬们的带领下系统的去学习web安全，所以很感谢他们在我学习迷茫之际指引出一条路。

<!-- more -->

## Nginx的安装
由于这是我们第一次使用apt此会话，因此请先更新服务器的软件包索引。然后，安装服务器：
```
$ sudo apt-get update
$ sudo apt-get install nginx
```
安装完毕后，输入``127.0.0.1``如下图所示即安装成功

![1.png](https://i.loli.net/2019/07/21/5d33da5125ab893181.png)

默认HTML文档储存在``/var/www/html``中

## MYSQL的安装
安装Mysql Server数据库，键入：
```
$ sudo apt-get install mysql-server
```
现在已安装MySQL数据库软件，但其配置尚未完成。

为了确保安装，MySQL附带了一个脚本，该脚本将询问我们是否要修改一些不安全的默认值。键入以下命令启动脚本：
```
$ sudo mysql_secure_installation
```
初始化设置完成后即可启动Mysql Server：
```
$ sudo mysql
```
根 MySQL用户设置为auth_socket默认使用插件进行身份验证，而不是使用密码进行身份验证。为了使后续连接Mysql方便我们要重新设置根用户的密码。
密码级别默认是1，即MEDIUM，所以刚开始设置的密码必须符合长度，且必须含有数字，小写或大写字母，特殊字符。
为了后续方便我们把密码设为简单的数字。
键入：
```mysql
//修改密码级别
mysql> set global validate_password_policy=0;
//修改密码长度（默认是8）
mysql> set global validate_password_length=4;
//修改密码
mysql> ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '123456';
//重新加载授权表
mysql> FLUSH PRIVILEGES;
```

***注意:*** 配置根 MySQL用户使用密码进行身份验证后，您将无法再sudo mysql使用先前使用的命令访问MySQL 。相反，您必须运行以下命令：
```
mysql -u root -p 123456
```
方可登陆

## 安装PHP并配置Nginx以使用PHP处理器
由于Nginx不像其他一些Web服务器那样包含本机PHP处理，因此需要安装``php-fpm``，它代表“``fastCGI进程管理器``”。我们将告诉Nginx将PHP请求传递给该软件进行处理。
1. 将universe添加Ubuntu的存储库中
    ```
    $ sudo add-apt-repository universe
    ```
2. 安装``php-fpm``模块以及一个额外的帮助程序包``php-mysql``
   ```
   $ sudo apt-get php-fpm php-mysql
   ```
3. 配置编辑新的服务器块配置文件，而不是编辑默认配置文件，这样能够在需要时轻松恢复默认配置。
   ```
   $ sudo vim /etc/nginx/sites-available/wh1teze.com
   ```
   编写wh1teze.com配置文件
   ```
   server {
        listen 80;
        root /var/www/html;
        index index.php index.html index.htm index.nginx-debian.html;
        server_name wh1teze.com;

        location / {
                try_files $uri $uri/ =404;
        }

        location ~ \.php$ {
                include snippets/fastcgi-php.conf;
                fastcgi_pass unix:/var/run/php/php7.2-fpm.sock;
        }

        location ~ /\.ht {
                deny all;
        }
    }
   ```
4. 添加此配置文件到``sited-enabled``目录创建符号链接来启用新服务器块
   ```
   $ sudo ln -s /etc/nginx/sites-available/wh1teze.com /etc/nginx/sites-enabled
   ```
   同时取消链接默认配置
   ```
   $ sudo unlink /etc/nginx/sites-enabled/default
   ```
5. 键入以下命令测试新配置文件的语法错误：
   ```
   $ sudo nginx -t
   ```
   如果报告了任何错误，请返回并重新检查您的文件，然后再继续。

6. 准备好后，重新加载Nginx以进行必要的更改：
   ```
   $ sudo systemctl reload nginx
   ```
## 创建PHP文件以测试配置
使用文本编辑器创建info.php在文档根目录中调用的测试PHP文件：
```
$ sudo vim /var/www/html/info.php
```
编写测试文件：
``` php
<?php
    phpinfo();
?>
```
保存退出后，通过浏览器访问此页面
```
http://127.0.0.1/info.php
```
![2.png](https://i.loli.net/2019/07/23/5d3719660acb744748.png)

## 另一种Nginx配置方式（写错php代码的折腾）
上次搭建完成后，访问``info.php``显示空白页，自己又get到了另一种配置方式，即用TCP的方式解析php文件。
配置修改``/etc/nginx/sites-available/default``中的代码：
```
location ~ \.php$ {  
        fastcgi_pass 127.0.0.1:9000; 
        fastcgi_index index.php; 
        fastcgi_param SCRIPT_FILENAME
        $document_root$fastcgi_script_name; 
        include fastcgi_params; 
}
```
其中``$document_root``为网站根目录。
因为是使用``127.0.0.1:9000``来监听解析php，所以要将``www.conf``中
```
listen = /run/php/php7.2-fpm.sock
```
改为
```
listen = 127.0.0.1:9000
```
修改完毕后，键入：
```
$ sudo systemctl reload nginx
$ sudo systemctl reload php-fpm7.2
```
重新加载``Nginx``和``php-fpm``，然后访问``127.0.0.1/info.php``。
![2.png](https://i.loli.net/2019/07/23/5d3719660acb744748.png)

## 连接到Mysql
编写连接Mysql的测试代码：
``` php
<?php
  $mysql_array = array(
	  'host' => '127.0.0.1',超时时间之后会关闭这个连接
	  'db_user' => 'root',
	  'db_pwd' => '123456',
	);
  $mysqli = @new mysqli($mysql_array['host'], $mysql_array['db_user'], $mysql_array['db_pwd']);
  if (mysqli_connect_error()){
	echo "connect mysql fail";
  }
	echo "connect mysql success!";
  $mysqli->close();
?>
```

访问``127.0.0.1/MysqlTest.php``，如下图所示：

![3.png](https://i.loli.net/2019/07/25/5d3916566153d77732.png)
成功连接到Mysql数据库。

# Nginx安全加固
配置完Nginx环境后，利用Nginx对web应用进行加固。

## 日志配置
1. 修改``nginx.conf``配置文件，设置日志格式：
   
```php
   log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
   '$status $body_bytes_sent "$http_referer" '
   '"$http_user_agent" "$http_x_forwarded_for"';    
```

2. 设置日志文件保存路径
   
```php
access_log logs/host.access.log main；
```   

3. 保存，重启nginx服务。

## 禁止目录浏览

修改``nginx.conf``文件，在``http``模块内添加：

```php
autoindex off;
```

## 实践中的漏洞

### 屏蔽恶意IP

利用``geoip``模块封杀掉除国内的所有IP：

```php
if ( $geoip_country_code !~  ^(CN)$ ) {
        return 403;
}
```

### 过滤user-agent
ser-agent 也即浏览器标识，每个正常的web请求都包含用户的浏览器信息，除非经过伪装，恶意扫描工具一般都会在user-agent里留下某些特征字眼，比如scan，nmap等。我们可以用正则匹配这些字眼，从而达到过滤的目的。

```php
if ($http_user_agent ~* "java|python|perl|ruby|curl|bash|echo|uname|base64|decode|md5sum|select|concat|httprequest|httpclient|nmap|scan" ) {
    return 403;
}
if ($http_user_agent ~* "" ) {
    return 403;
}

```

### 禁用非安全的HTTP请求

```php
if ($request_method !~ ^(GET|POST|HEAD)$ ) {
    return 405;
}
 
if ($http_range ~ "\d{9,}") {
    return 444;
}

```

### URL参数过滤敏感字

```php
if ($query_string ~* "union.*select.*\(") { 
    rewrite ^/(.*)$  $host  permanent;
} 
 
if ($query_string ~* "concat.*\(") { 
    rewrite ^/(.*)$  $host  permanent;
}
```

### 清除不安全的HTTP头

```php
more_clear_headers "X-Powered-By";
more_clear_headers "Server";
more_clear_headers "ETag";
more_clear_headers "Connection";
more_clear_headers "Date";
more_clear_headers "Accept-Ranges";
more_clear_headers "Last-Modified";
```

### 防止XSS攻击

```php
    add_header X-XSS-Protection "1; mode=block";
```

### 避免点击拦截

```php
    add_header X-Frame-Options "SAMEORIGIN"; 
```

### 防止特定目录的PHP执行权限

```php
//去掉单个目录的PHP执行权限
location ~ /attachments/.*\.(php|php5)?$ {
        deny all;
}

//去掉多个目录的PHP执行权限
location ~
/(attachments|upload)/.*\.(php|php5)?$ {
deny all;
}
```

### 通过关闭慢连接来抵御一些DDOS攻击

```php
 //读取客户端请求体的超时时间
client_body_timeout 5s; 
//读取客户端请求头的超时时间
client_header_timeout 5s;
//超时时间之后会关闭这个连接
keepalive_timeout 75s;
```

## 风险操作项

### Nginx降权

设置``nginx``用户权限为``nobody``

```php
　user nobody;
```

### 防盗链

```php
location ~* ^.+\.(gif|jpg|png|swf|flv|rar|zip)$ {
    valid_referers none blocked server_names *.nsfocus.com http://localhost baidu.com;
    if ($invalid_referer) {
        rewrite ^/ [img]http://www.XXX.com/images/default/logo.gif[/img];
        # return 403;
    }
}
```
