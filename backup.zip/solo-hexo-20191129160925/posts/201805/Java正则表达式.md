title: Java正则表达式
date: '2018-05-14 04:11:48'
updated: '2018-05-14 04:11:48'
tags: [-Java, -正则表达式]
permalink: /articles/2018/05/14/1575014359486.html
---
最近有点脑短路, 老是爱丢东西, U盘、眼睛、雨伞都一一抛弃了我，去了未知的地方。数据结构课随着离散数学的结课而出现，大佬们刷作业OJ还是那么地快。

{%asset_img 3.jpg%}

而我还是努力去追赶大佬们的脚步,继续进行Java的学习。{%asset_img 1.gif%}

最近了解了正则表达式在这里总结一下

<!-- more -->

# 正则表达式

## 使用概述

### 使用正则表达式操作字符串主要涉及两个类：

◆ java.util.regex.Pattern类：是正则表达式的编译表现形式，正则表达式必须被编译为此类的实例。

◆ java.util.regex.Matcher类：通过解释Pattern对字符串执行匹配操作的匹配器。

### 它们的关键用法如下：

◆Pattern的compile静态方法将正则表达式编译成一个Pattern对象。

◆Pattern的matcher实例方法获得一个匹配器（Matcher对象），参数为待匹配的字符串。

◆Pattern的split实例方法将字符串按照正则表达式分解成多个字串。

◆Matcher的matches方法尝试将整个字符串与Pattern相匹配。

◆Matcher的find方法扫描字符串，以查找与Pattern匹配的下一个子串

◆Matcher的replaceAll方法将字符串中的与Pattern匹配的子串全部用新的子串替换掉。

## 实例演示

### 一:正则表达式语法



| 符号 | 描述                       |
| :--: | -------------------------- |
|  ^   | 匹配字符串的开头           |
|  $   | 匹配字符串的结尾           |
|  *   | 匹配0个或者多个前面字符    |
|  +   | 匹配至少一个字符           |
|  ?   | 匹配0个或者一个字符        |
|  .   | 匹配除换行符以外的任何字符 |

#### 示例一：

```java
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class RegexExpression{
    //利用正则表达式查找匹配字符串
	public static boolean find(String str, String regex) {
		Pattern p = Pattern.compile(regex);   //将正则表达式编译成一个Pattern
		Matcher m = p.matcher(str);   //创建一个Matcher
		//Matcher的find方法用来查找或者匹配, 只有能找到满足正则表达式的子串,就返回true
        System.out.println("\"" + str + "\" 匹配正则表达式 \"" + regex + "\"  ?  " + b);
		boolean b = m.find();
		return b;
	}
    public static void main(String[] args){
        //^符号匹配字符串的开头
		//匹配以abc开头的字符串
		RegexExpression.find("abcdef", "^abc");  
		RegexExpression.find("Abc def", "^abc"); 
		System.out.println();
		
		// $符号匹配字符串的结尾
		// 匹配以def结尾的字符串
		RegexExpression.find("Aabcdef", "def$"); 
		RegexExpression.find("AabcdeF", "def$");
		//如果同时使用^和$符号, 则将进行精确匹配
		RegexExpression.find("def", "^def$");
		RegexExpression.find("adcdefg", "^def$");
		System.out.println();
		
		// *符号匹配0个或者多个前面的字符
		RegexExpression.find("a", "ab*");
		RegexExpression.find("ab", "ab*");
		RegexExpression.find("abbb", "ab");
		System.out.println();
		
		// +符号匹配至少一个前面的字符
		RegexExpression.find("a", "ab+");
		RegexExpression.find("ab", "ab+");
		RegexExpression.find("abbb", "ab+");
		System.out.println();
		
		// ?符号匹配0个或1个前面的字符
		RegexExpression.find("a", "ab?c?");
		RegexExpression.find("ab", "ab?c?");
		RegexExpression.find("abc", "ab?c?");
		RegexExpression.find("abbcb", "ab?c?");
		System.out.println();
		
		// .符号匹配除换行符以外的任何字符
		RegexExpression.find("a", ".");
		// .与+连用能匹配除换行符以外的任何字符
		RegexExpression.find("dasf4566a`1234=-=4bsd",  ".+");
		System.out.println();
		
		// x | y 匹配"x"或"y"
		// abc | xyz 可匹配 "abc"或者 "xyz", 而"ab ( c | x ) yz"匹配 "abcyz" 和 "zbxyz"
		RegexExpression.find("x", "x|y");
		RegexExpression.find("y", "x|Y");
		RegexExpression.find("abc",  "abc|xyz");
		RegexExpression.find("xyz",  "abc|xyz");
		RegexExpression.find("abc", "ab(c|x)yz");
		RegexExpression.find("abcyz", "ab(c|x)yz");
		System.out.println();
    }
}
```

#### 输出:

```
"abcdef" 匹配正则表达式 "^abc"  ?  true
"Abc def" 匹配正则表达式 "^abc"  ?  false

"Aabcdef" 匹配正则表达式 "def$"  ?  true
"AabcdeF" 匹配正则表达式 "def$"  ?  false
"def" 匹配正则表达式 "^def$"  ?  true
"adcdefg" 匹配正则表达式 "^def$"  ?  false

"a" 匹配正则表达式 "ab*"  ?  true
"ab" 匹配正则表达式 "ab*"  ?  true
"abbb" 匹配正则表达式 "ab"  ?  true

"a" 匹配正则表达式 "ab+"  ?  false
"ab" 匹配正则表达式 "ab+"  ?  true
"abbb" 匹配正则表达式 "ab+"  ?  true

"a" 匹配正则表达式 "ab?c?"  ?  true
"ab" 匹配正则表达式 "ab?c?"  ?  true
"abc" 匹配正则表达式 "ab?c?"  ?  true
"abbcb" 匹配正则表达式 "ab?c?"  ?  true

"a" 匹配正则表达式 "."  ?  true
"dasf4566a`1234=-=4bsd" 匹配正则表达式 ".+"  ?  true

"x" 匹配正则表达式 "x|y"  ?  true
"y" 匹配正则表达式 "x|Y"  ?  false
"abc" 匹配正则表达式 "abc|xyz"  ?  true
"xyz" 匹配正则表达式 "abc|xyz"  ?  true
"abc" 匹配正则表达式 "ab(c|x)yz"  ?  false
"abcyz" 匹配正则表达式 "ab(c|x)yz"  ?  true
```



| 符号       | 描述                                            |
| ---------- | ----------------------------------------------- |
| {n}        | 匹配恰好n次(n为非负数)前面的字符                |
| {n,}       | 匹配至少n次(n为非负数)前面的字符                |
| {m,n}      | 匹配至少m个,至多n个前面的字符                   |
| [xyz]      | 表示一个字符集,匹配括号中的字符之一             |
| [^xyz]     | 表示一个否定字符集,匹配不在此括号中的任意字符   |
| [a-z]      | 匹配从"a"到"z"之间的任意一个小写字符            |
| [^a-z]     | 表示某个范围之外的字符,匹配不在指定范围内的字符 |
| [a-zA-Z]   | 表示a到z或A到Z (即全部字母)                     |
| [a-z-[bc]] | 表示a到z, 除了b和c                              |

#### 示例二:

```java
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class RegexExpression{
    //利用正则表达式查找匹配字符串
	public static boolean find(String str, String regex) {
		Pattern p = Pattern.compile(regex);   //将正则表达式编译成一个Pattern
		Matcher m = p.matcher(str);   //创建一个Matcher
		//Matcher的find方法用来查找或者匹配, 只有能找到满足正则表达式的子串,就返回true
        System.out.println("\"" + str + "\" 匹配正则表达式 \"" + regex + "\"  ?  " + b);
		boolean b = m.find();
		return b;
	}
    public static void main(String[] args){
        // {n}匹配恰好n次(n为非负数) 前面的字符
		RegexExpression.find("aa", "a{3}");
		RegexExpression.find("aaa", "a{3}");
		System.out.println();
		
		// {n, }匹配至少n次 ( n为非负整数 )前面的字符
		RegexExpression.find("aaa", "a{3,}");
		RegexExpression.find("aaaaa", "a{3,}");
		System.out.println();
		
		// {m,n} 匹配至少m个,至多n个前面的字符
		RegexExpression.find("aaa", "a{3,4}");
		RegexExpression.find("aaaa", "a{3,4}");
		RegexExpression.find("aaaaa", "a{3,4}");
		System.out.println();
		
		// [xyz]表示一个字符集, 匹配括号中的字符之一
		RegexExpression.find("a", "[abc]");
		RegexExpression.find("b", "[abc]");
		RegexExpression.find("c", "[abc]");
		RegexExpression.find("ab", "[abc]");
		System.out.println();
		
		// [^xyz] 表示一个否定的字符集, 匹配不在此括号中的任意字符
		RegexExpression.find("a", "[^abc]");
		RegexExpression.find("x", "[^abc]");
		RegexExpression.find("8", "[^abc]");
		System.out.println();
		
		// [a-z]匹配从"a"到"z"之间的任何一个小写字符
		RegexExpression.find("c", "[b-d]");
		RegexExpression.find("f", "[b-d]");
		RegexExpression.find("$", "[b-d]");
		System.out.println();
		
		// [^a-z]表示某个范围之外的字符,匹配不在指定范围内的字符
		RegexExpression.find("f","[^b-d]");
		RegexExpression.find("b", "[^b-d]");
		System.out.println();
		
		// [a-zA-Z] 表示a到z或A到Z (即全部字母)
		RegexExpression.find("B",  "[a-cA-F]");
		RegexExpression.find("G",  "[a-cA-F]");
		System.out.println();
		
		// [a-z-[bc]] 表示a到z, 除了b和c
		RegexExpression.find("c", "[a-z-[bcd]]");
		RegexExpression.find("e", "[a-z-[bcd]]");
		RegexExpression.find("f", "[a-z-[bcd]]");
    }
}
```

#### 输出:

```
"aa" 匹配正则表达式 "a{3}"  ?  false
"aaa" 匹配正则表达式 "a{3}"  ?  true

"aaa" 匹配正则表达式 "a{3,}"  ?  true
"aaaaa" 匹配正则表达式 "a{3,}"  ?  true

"aaa" 匹配正则表达式 "a{3,4}"  ?  true
"aaaa" 匹配正则表达式 "a{3,4}"  ?  true
"aaaaa" 匹配正则表达式 "a{3,4}"  ?  true

"a" 匹配正则表达式 "[abc]"  ?  true
"b" 匹配正则表达式 "[abc]"  ?  true
"c" 匹配正则表达式 "[abc]"  ?  true
"ab" 匹配正则表达式 "[abc]"  ?  true

"a" 匹配正则表达式 "[^abc]"  ?  false
"x" 匹配正则表达式 "[^abc]"  ?  true
"8" 匹配正则表达式 "[^abc]"  ?  true

"c" 匹配正则表达式 "[b-d]"  ?  true
"f" 匹配正则表达式 "[b-d]"  ?  false
"$" 匹配正则表达式 "[b-d]"  ?  false

"f" 匹配正则表达式 "[^b-d]"  ?  true
"b" 匹配正则表达式 "[^b-d]"  ?  false

"B" 匹配正则表达式 "[a-cA-F]"  ?  true
"G" 匹配正则表达式 "[a-cA-F]"  ?  false

"c" 匹配正则表达式 "[a-z-[bcd]]"  ?  true
"e" 匹配正则表达式 "[a-z-[bcd]]"  ?  true
"f" 匹配正则表达式 "[a-z-[bcd]]"  ?  true
```



| 符号     | 描述                                                         |
| -------- | ------------------------------------------------------------ |
| 特殊字符 | \n为换行符; \f为分页符; \r为回车符; \t为制表符               |
| \\\      | 表示转移符\, 在使用时要用\\\\\\\\表示\\\\, \\\\表示\         |
| \s       | 表示任意空白字符, 包括空格, 制表符, 分页符等, 等价于"[\f\n\r\t]" |
| \S       | 表示任何非空白字符,等价于"[^\f\n\r\t]"                       |
| \w       | 表示任何单词字符, 包括字母和下划线, 等价于"[A-Za-z0-9_]"     |
| \W       | 表示任何非单词字符, 等价于"[ ^A-Za-z0-9_]"                   |
| \d       | 匹配一个数字字符, 等价于[0-9]                                |
| \D       | 匹配一个非数字字符, 等价于[ ^0-9]                            |
| \b       | 匹配单词的结尾                                               |
| \B       | 匹配单词的开头                                               |

#### 示例三:

```java
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class RegexExpression{
    //利用正则表达式查找匹配字符串
	public static boolean find(String str, String regex) {
		Pattern p = Pattern.compile(regex);   //将正则表达式编译成一个Pattern
		Matcher m = p.matcher(str);   //创建一个Matcher
		//Matcher的find方法用来查找或者匹配, 只有能找到满足正则表达式的子串,就返回true
        System.out.println("\"" + str + "\" 匹配正则表达式 \"" + regex + "\"  ?  " + b);
		boolean b = m.find();
		return b;
	}
    public static void main(String[] args){
        //特殊字符, \n为换行符; \f为分页符; \r为回车符; \t为制表符
		RegexExpression.find("\n", "\n");
		RegexExpression.find("\f", "\f");
		RegexExpression.find("\r", "\r");
		RegexExpression.find("\t", "\t");
		
		//  \\表示转移符\, 在使用时要用\\\\表示\\, \\表示\
		RegexExpression.find("\\", "\\\\");
		System.out.println();
		
		//  \s 表示任意空白字符, 包括空格, 制表符, 分页符等, 等价于"[\f\n\r\t]"
		// 使用\s时前面要再加一个\
		RegexExpression.find("\n", "\\s");
		RegexExpression.find("\f", "\\s");
		RegexExpression.find("\r", "\\s");
		RegexExpression.find("\t", "\\s");
		System.out.println();
		
		//  \S表示任何非空白字符,等价于"[^\f\n\r\t]"
		// 使用\S时要在前面再加上\
		RegexExpression.find("\n", "\\S");
		RegexExpression.find("\f", "\\S");
		RegexExpression.find("a", "\\S");
		RegexExpression.find("9", "\\S");
		System.out.println();
		
		//  \w表示任何单词字符, 包括字母和下划线, 等价于"[A-Za-z0-9_]"
		// 使用时用\\w
		RegexExpression.find("a", "\\w");
		RegexExpression.find("9", "\\w");
		RegexExpression.find("X", "\\w");
		RegexExpression.find("_", "\\w");
		System.out.println();
		
		// \W表示任何非单词字符, 等价于"[^A-Za-z0-9_]"
		// 使用时用\\W
		RegexExpression.find("a", "\\W");
		RegexExpression.find("9", "\\W");
		RegexExpression.find("$", "\\W");
		RegexExpression.find("#", "\\W");
		System.out.println();
		
		//  \d匹配一个数字字符, 等价于[0-9]
		RegexExpression.find("6", "\\d");
		RegexExpression.find("9", "\\d");
		RegexExpression.find("A", "\\d");
		System.out.println();
		
		//  \D匹配一个非数字字符, 等价于[^0-9]
		RegexExpression.find("%", "\\D");
		RegexExpression.find("$", "\\D");
		RegexExpression.find("A", "\\D");
		RegexExpression.find("8", "\\D");
		System.out.println();
		
		//  \b匹配单词的结尾
		RegexExpression.find("love", "ve\\b");
		RegexExpression.find("very", "ve\\b");
		System.out.println();
		
		//  \B匹配单词的开头
		RegexExpression.find("love", "ve\\B");
		RegexExpression.find("very", "ve\\B");
		System.out.println();
		
    }
}
```

#### 输出:

```
" 匹配正则表达式 "
"  ?  true
"_" 匹配正则表达式 "_"  ?  true
"
" 匹配正则表达式 "
"  ?  true
"	" 匹配正则表达式 "	"  ?  true
"\" 匹配正则表达式 "\\"  ?  true

"
" 匹配正则表达式 "\s"  ?  true
"_" 匹配正则表达式 "\s"  ?  true
"
" 匹配正则表达式 "\s"  ?  true
"	" 匹配正则表达式 "\s"  ?  true

"
" 匹配正则表达式 "\S"  ?  false
"_" 匹配正则表达式 "\S"  ?  false
"a" 匹配正则表达式 "\S"  ?  true
"9" 匹配正则表达式 "\S"  ?  true

"a" 匹配正则表达式 "\w"  ?  true
"9" 匹配正则表达式 "\w"  ?  true
"X" 匹配正则表达式 "\w"  ?  true
"_" 匹配正则表达式 "\w"  ?  true

"a" 匹配正则表达式 "\W"  ?  false
"9" 匹配正则表达式 "\W"  ?  false
"$" 匹配正则表达式 "\W"  ?  true
"#" 匹配正则表达式 "\W"  ?  true

"6" 匹配正则表达式 "\d"  ?  true
"9" 匹配正则表达式 "\d"  ?  true
"A" 匹配正则表达式 "\d"  ?  false

"%" 匹配正则表达式 "\D"  ?  true
"$" 匹配正则表达式 "\D"  ?  true
"A" 匹配正则表达式 "\D"  ?  true
"8" 匹配正则表达式 "\D"  ?  false

"love" 匹配正则表达式 "ve\b"  ?  true
"very" 匹配正则表达式 "ve\b"  ?  false

"love" 匹配正则表达式 "ve\B"  ?  false
"very" 匹配正则表达式 "ve\B"  ?  true
```





<br>

### 二:测试利用正则表达式精确匹配字符串

#### 示例:

~~~java
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexExpression {
    // 测试利用正则表达式精确匹配字符串
	public static void testMatch() {
		RegexExpression.find("abcdef", "^abc");
		RegexExpression.find("Aabc def", "^abc");
		RegexExpression.find("Aabcdef", "def$");
		RegexExpression.find("AabcdeF", "def$");
		RegexExpression.find("def", "^def$");
		
	}
	
	//精确匹配字符串和正则表达式. 所谓精确匹配是指字符串的每个字符都满足正则表达式
	public static boolean match(String str, String regex) {
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(str);
		boolean b = m.matches();
		System.out.println("\"" + str + "\"精确匹配正则表达式 \"" + regex + "\" ?" + b);
		return b;
	}
    public static void main(String[] args) {
        RegexExpression.testMatch();
    }
}
~~~

#### 输出:

```
"abcdef" 匹配正则表达式 "^abc"  ?  true
"Aabc def" 匹配正则表达式 "^abc"  ?  false
"Aabcdef" 匹配正则表达式 "def$"  ?  true
"AabcdeF" 匹配正则表达式 "def$"  ?  false
"def" 匹配正则表达式 "^def$"  ?  true
```



<br>

### 三.测试利用正则表达式替换字符串

#### 示例:

```java
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexExpression {
    // 测试利用正则表达式替换字符串
	public static void testReplace() {
		// 将字符串中重复的空格键替换为一个空格
		RegexExpression.replace("a    a    a   a", " {2,}", " ");
		RegexExpression.replace("abcad a", "a", "x");
	}
    
	/**
	 * 利用正则表达式替换字符串
	 * @param str 待转换的字符串
	 * @param regex 正则表达式
	 * @param newStr 用来替换的字符串
	 * 
	 */
	public static String replace(String str, String regex, String newStr) {
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(str);
		// 用新子串替换所有满足正则表达式的子串
		String s = m.replaceAll(newStr);
		System.out.println("\"" + str + "\"中匹配正则表达式 \"" + regex +
				"\"部分被 \"" + newStr + "\" 替换后: " + s);
		return s;
	}
    public static void main(String[] args) {
        RegexExpression.testReplace();
    }
}
```

#### 输出:

```
"a  a    a   a"中匹配正则表达式 " {2,}"部分被 " " 替换后: a a a a
"abcad a"中匹配正则表达式 "a"部分被 "x" 替换后: xbcxd x
```

<br>

### 四: 利用正则表达式分解字符串

#### 示例:

```java
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexExpression {
    	// 利用正则表达式分解字符串
	public static void testSplit() {
		// 按空格分解字符串, 空格符可以是多个连续的
		System.out.println("RegexExpression.split(\"ab   aba    a      bbc  bc\" ,\" + \", 5) : result");
		RegexExpression.outputStrArray(RegexExpression.split("ab   aba  a    bbc   bc", " +", 5));
		//按照字母b分解字符串
		System.out.println("RegexExpression.split(\"ab    aba a   bbc  bc\", \"b\", 5): result");
		RegexExpression.outputStrArray(RegexExpression.split("ab    aba a   bbc  bc", "b", 5));
		
	}
	/**
	 * 使用正则表达式分解字符串
	 * @param str 待分解的字符串
	 * @param regex 正则表达式
	 * @param count 最终被分成的段数最大值
	 * 
	 */
	public static String[] split(String str, String regex, int count) {
		Pattern p = Pattern.compile(regex);
		//按照符合正则表达式的子串分解字符串
		return p.split(str, count);
		
	}
	
	//输出字符串数组
	public static void outputStrArray(String[] array) {
		if(array != null) {
			for(int i = 0; i < array.length; i++) {
				System.out.println(i + ": " + array[i]);
			}
		}
	}
    public static void main(String[] args) {
        RegexExpression.testSplit();
    }
}
```

#### 输出:

```
RegexExpression.split("ab   aba    a      bbc  bc" ," + ", 5) : result
0: ab
1: aba
2: a
3: bbc
4: bc
RegexExpression.split("ab    aba a   bbc  bc", "b", 5): result
0: a
1:     a
2: a a   
3: 
4: c  bc
```

### 五:查找并替换, 替换前两个满足正则表达式的子串

#### 示例:

```java
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexExpression {
    public static void main(String[] args) {
        //查找并替换, 替换前两个满足正则表达式的子串
		Pattern p = Pattern.compile("a+");
		Matcher m = p.matcher("bba   bb  aaa   bbabb  bab");
		StringBuffer sb = new StringBuffer();
		int i = 0;
		while((m.find())&&(i < 2)) {
			//将字符串中匹配的部分替换
			//并且两次匹配之间(包括被匹配的部分)的字符串追加到sb后
			m.appendReplacement(sb, "XX");
			i++;
			}
		// 将字符串中没有进行匹配的部分全部追加到sb后面
		m.appendTail(sb);
		System.out.println(sb.toString());
    }
}
```

#### 输出:

```
bbXX   bb  XX   bbabb  bab
```



<br>

<br>

## 番外

其实java.lang.String类中提供了Matches(public boolean matches(String regex))方法来判断该字符串是否与regex正则表达式匹配成功；split方法按照正则表达式分解字符串；replaceAll方法用给定的替换字符替换与正则表达式匹配的此字符串的每个子串。

### 示例：

```java
public class Pattern {
	public static void testRegex() {
		String str = "aab         aaa         bb   cc   dd";
		String pattern1 = "^[a-zA-Z|| ]*$";      //该正则表达式表示包含任意多个英文字母或者空格
		System.out.println("用正则表达式匹配成功? " + str.matches(pattern1));
		//将字符串中的连续空格换成一个空格
		System.out.println(str.replaceAll("\\s{2,}", ""));
		//将字符串中的第一个连续空格转换为一个空格
		System.out.println(str.replaceFirst("\\s{2,}"," "));
		
		//分解字符串,按空格分解, 多个连续的空格当做一个空格
		String[] ss = str.split("\\s{1,}");
		System.out.println("用正则表达式按空格分解: ");
		System.out.println(ss.length);
		for(String s :ss) {
			System.out.println(s);
		}
		//限制分解后的数组大小
		System.out.println("用正则表达式按空格分解, 指定最大分解段数为3: ");
		ss = str.split("\\s{1,}", 3);
		System.out.println(ss.length);
		for(String s:ss) {
			System.out.println(s);
		}
	}
	public static void main(String[] args) {
		Pattern.testRegex();
	}
}
```

### 输出:

```
用正则表达式匹配成功? true
aab aaa bb cc dd
aab aaa         bb   cc   dd
用正则表达式按空格分解: 
5
aab
aaa
bb
cc
dd
用正则表达式按空格分解, 指定最大分解段数为3: 
3
aab
aaa
bb   cc   dd
```



**最近学习心态有点急躁，导致好多知识点遗忘或者混淆。**

**丧**

{%asset_img 2.jpg%}