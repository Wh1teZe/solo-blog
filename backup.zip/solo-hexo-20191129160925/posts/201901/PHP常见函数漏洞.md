title: PHP常见函数漏洞
date: '2019-01-04 02:23:13'
updated: '2019-01-04 02:23:13'
tags: [CTF, PHP安全, web]
permalink: /articles/2019/01/04/1575014352607.html
---
# PHP常见函数安全
---
最近学习CTF中涉及到简单的PHP代码审计,借这个机会总结一下PHP常见的函数漏洞
<!-- more -->
## 1.判断比较类型

### 1.1 "=="和"==="弱比较

+ ``==`` 进行比较时对于类型不同的数据,会将其转换成相同的数据类型在进行比较
{% asset_img 1.PNG%}
对于十六进制``0e``开头的字符串数据,比较时PHP会把其当做科学计数法处理,即 ``0的任意次方恒为0``
那么PHP是如何将一个字符串转化为数值的呢,我们翻翻PHP手册可以看到
  ```
  当一个字符串被当作一个数值来取值，其结果和类型如下：如果该字符串没有包含 ‘.’，’e’ 或 ‘E’ 
  并且其数字值在整型的范围之内（由 PHP_INT_MAX 所定义），该字符串将被当成 integer 来取值。
  其它所有情况下都被作为 float 来取值。该字符串的开始部分决定了它的值。如果该字符串以合法的
  数值开始，则使用该数值。否则其值为 0（零）。合法数值由可选的正负号，后面跟着一个或多个数字
  （可能有小数点），再跟着可选的指数部分。指数部分由 ‘e’ 或 ‘E’ 后面跟着一个或多个数字构成。
  ```
  下面官方手册给出的例子:

  ``` php
  <?php
  $foo = 1 + "10.5";                // $foo is float (11.5)
  $foo = 1 + "-1.3e3";              // $foo is float (-1299)
  $foo = 1 + "bob-1.3e3";           // $foo is integer (1)
  $foo = 1 + "bob3";                // $foo is integer (1)
  $foo = 1 + "10 Small Pigs";       // $foo is integer (11)
  $foo = 4 + "10.2 Little Piggies"; // $foo is float (14.2)
  $foo = "10.0 pigs " + 1;          // $foo is float (11)
  $foo = "10.0 pigs " + 1.0;        // $foo is float (11)     
  ?>
  ```

  那么我们就这样认为：
  - ``合法数字`` + ``无法解释为数字的字符串`` 将会转换为合法数字
  - ``无法解释为数字的字符串`` + ``任意类型`` 将会转换为0
  - ``合法数字`` + ``e`` + ``合法数字`` 将会被解释为科学计数法

  当然这个也可以用于 ``switch()`` 判断：
  {% asset_img 2.PNG%}
  <br>
+ ``===`` 会判断数值和数据类型是否相同,但当比较对象为数组时,比较对象会被当做 ``NULL`` 导致 ``NULL === NULL`` 返回 ``true``。
<br>

### 1.2 strcmp()利用数组绕过(适用于PHP5.3之前的版本)

**strcmp()** 这个方法是用来比较字符串的函数。

``` php
int strcmp ( string $str1 , string $str2 )

Return Values

Returns < 0 if str1 is less than str2; > 0 if str1 is greater than str2, and 0 if they are equal.
```

可知，传入的期望类型是字符串类型的数据，但是如果我们传入非字符串类型的数据的时候，这个函数将会有怎么样的行为呢？实际上，当这个函数接受到了不符合的类型，这个函数将发生错误，但是在 ``PHP5.3`` 之前中，显示了报错的警告信息后，将 ``return 0``。
看一下存在strcmp的CTF题目：

``` php
<?php
$flag = "flag{xxxxx}";
if (isset($_GET['a'])) {
if (strcmp($_GET['a'], $flag) == 0) 
//比较两个字符串（区分大小写）
die('Flag: '.$flag);
else
print 'No';
}
?>
```

我们构造payload:``?a[]=xxx`` 即可得到flag。
<br>
### 1.3 sha1()和MD5()加密比较
在这两个函数中规定加密的对象不能为数组,否则就会 ``return false`` 同样我们那相关的ctf题目做例:

``` php
<?php
$flag = "flag";
if (isset($_GET['name']) and isset($_GET['password']))
{
  var_dump($_GET['name']);
  echo "";
  var_dump($_GET['password']);
  var_dump(sha1($_GET['name']));
  var_dump(sha1($_GET['password']));
  if ($_GET['name'] == $_GET['password']){
    echo 'Your password can not be your name!';
  }
  else if (sha1($_GET['name']) === sha1($_GET['password'])){
   die('Flag: '.$flag);
  }
  else
  echo 'Invalid password.';
}
else
echo 'Login first!';
?>
```

我们构造payload: ``?name[]=1&password[]=2`` 得到flag。
**MD5()函数** 亦是如此,当然如果 ``MD5()`` 用 ``==`` 比较时除了使用数组绕过还可以加密后以`0e`开头的的特殊字符(``240610708``、``QNKCDZO``、``aabg7XSs``、``aabC9RqS``)绕过。
### 1.4 in_array()弱比较
**in_array()**函数,in_array()有三个参数值,即
```php
bool in_array ( mixed $needle , array $haystack [, bool $strict = FALSE ] )
```
如果我们没有设置``strict``为``true``则是进行宽松比较,相当于``==``,而``strict``设置为``true``时会比较``needle``和``haystack``的类型是否相同,相当于``===``。
{% asset_img 3.PNG %}
******
## 2.变量覆盖漏洞

变量覆盖指的是用我们自定义的参数值替换程序原有的变量值，一般变量覆盖漏洞需要结合程序的其它功能来实现完整的攻击。
经常导致变量覆盖漏洞场景有：``$$``，``extract()函数``,``parse_str()函数``，``import_request_variables()``使用不当，开启了全局变量注册等。

### 2.1 $$导致的变量覆盖问题

使用foreach来遍历数组中的值，然后再将获取到的数组键名作为变量，数组中的键值作为变量的值。因此就产生了变量覆盖漏洞。

``` php
<?php
foreach (array('_COOKIE','_POST','_GET') as $_request)  
{
    foreach ($$_request as $_key=>$_value)  
    {
        $$_key=  $_value;
    }
}
$id = isset($id) ? $id : 2;
if($id == 1) {
    echo "flag{xxxxxxxxxx}";
    die();
}
echo $id;
?>
```

构造payload: ``?id=1``,则会导致原变量``id``的值被覆盖
<br>
### 2.2 extract()变量覆盖

**extract()** 函数从数组中将变量导入到当前的符号表。该函数使用数组键名作为变量名，使用数组键值作为变量值。针对数组中的每个元素，将在当前符号表中创建对应的一个变量。
如下示例:
``` php
<?php
$id=1;  
extract($_GET);
echo $id;
?>
```
同样构造payload: ``?id=1``,则会导致原变量``id``的值被覆盖
<br>
### 2.3 parse_str()变量覆盖

**parse_str()** 函数把查询字符串解析到变量中，如果没有array 参数，则由该函数设置的变量将覆盖已存在的同名变量。
同样拿ctf题举例:
``` php
<?php
error_reporting(0);
if (empty($_GET['id'])) {
    show_source(__FILE__);
    die();
} else {
    include (‘flag.php’);
    $a = “www.OPENCTF.com”;
    $id = $_GET['id'];
    @parse_str($id);
    if ($a[0] != ‘QNKCDZO’ && md5($a[0]) == md5(‘QNKCDZO’)) {
        echo $flag;
    } else {
        exit(‘其实很简单其实并不难！’);
    }
  }
?>
```
这个也用到了``==``的弱比较,所以我们构造payload: ``?id=a[0]=240610708``,get到flag。
****
## 3.其它的漏洞

### 3.1 ereg()函数

**ereg()** 函数, 存在于``PHP 5.3`` 版本之前,以区分大小写的方式在string中寻找与给定的pattern所匹配的子串,这个函数存在两个漏洞
- ereg()函数存在NULL截断漏洞,导致正则过滤被绕过,所以可以使用``%00``截断正则匹配;
- ereg()只能处理字符串,遇到数组做参数会返回NULL

拿ctf题目举例:

``` php
<?php
$flag = "xxx";
if (isset ($_GET['password']))
{
if (ereg ("^[a-zA-Z0-9]+$", $_GET['password']) === FALSE)
{
  echo 'You password must be alphanumeric';
}
else if (strlen($_GET['password']) < 8 && $_GET['password'] > 9999999)
{
if (strpos ($_GET['password'], '-') !== FALSE) //strpos — 查找字符串首次出现的位置
{
  die('Flag: ' . $flag);
}
else
{
  echo('- have not been found');
}
}
else
{
  echo 'Invalid password';
}
}
?>
```

这里要求``password``里只能包含字母和数字，这里可以用``%00``截断；同时``password``总长度必须小于8且值大于9999999，所以这里可以利用科学记数法``1e8``来表示10000000。 
构造payload:``?password=1e8%00-``以后显示``*-* have not been found``,最终构造payload为``?password=1e8%00*-*``