title: PHP文件包含漏洞
date: '2019-01-08 19:21:37'
updated: '2019-01-08 19:21:37'
tags: [CTF, PHP安全, web]
permalink: /articles/2019/01/08/1575014358187.html
---
# 文件包含漏洞
****
<!-- more -->
## 0x01 class_exists()任意文件访问漏洞

{% asset_img 2.png%}

上图中使用 **class_exists()** 函数来判断用户传过来的控制器是否存在，默认情况下，如果程序存在 **__autoload** 函数，那么在使用 **class_exists()** 函数就会自动调用本程序中的 **__autoload** 函数，这题的文件包含漏洞就出现在这个地方。攻击者可以使用 ``路径穿越`` 来包含任意文件，当然使用路径穿越符号的前提是 ``PHP5~5.3(包含5.3版本)``版本 之间才可以。例如类名为： ``../../../../etc/passwd`` 的查找，将查看``passwd``文件内容。

{% asset_img 3.PNG %}

我们来看一下PHP手册对 **class_exists()** 函数的定义：

> **class_exists** ：(PHP 4, PHP 5, PHP 7)
功能 ：检查类是否已定义
定义 ： ``bool class_exists ( string $class_name[, bool $autoload = true ] )``
 **$class_name**  为类的名字，在匹配的时候不区分大小写。默认情况下 **$autoload** 为 ``true`` ，当 **$autoload** 为 ``true`` 时，会自动加载本程序中的 **__autoload** 函数；当 **$autoload** 为 ``false`` 时，则不调用 **__autoload** 函数。
另外,当我们使用 **spl_autoload_register()** 函数来注册函数到 **__autoload** 队列时注册函数为 **spl_autoload()** 是也会产生漏洞

{% asset_img 4.png %}

{% asset_img 5.PNG %}

同看看PHP手册对 **spl_autoload()**函数的定义:


> 功能 : **__autoload()** 函数的默认实现
定义 : ``void spl_autoload ( string $class_name [, string $file_extensions ] )`` 
本函数提供了 **__autoload()** 的一个默认实现。如果不使用任何参数调用 **spl_autoload_register()** 函数，则以后在进行 **__autoload** 调用时会自动使用此函数。在默认情况下，本函数先将类名转换成小写，再在小写的类名后加上 ``.inc`` 或 ``.php`` 的扩展名作为文件名，然后在所有的包含路径 ``include paths`` 中检查是否存在该文件。