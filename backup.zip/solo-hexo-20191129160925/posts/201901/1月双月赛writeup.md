title: 1月双月赛writeup
date: '2019-01-29 17:30:05'
updated: '2019-01-29 17:30:05'
tags: [-CTF, -web]
permalink: /articles/2019/01/29/1575014359002.html
---
## 1月双月赛writeup

认清了自己和大佬们的差距 23333333333

<!-- more -->
### 1.签到题

一道简单的代码审计

![](https://0d077ef9e74d8.cdn.sohucs.com/rgvfnr2_png)
看到了常见的PHP可绕过函数。
用 **%00** 可绕过 **ereg()**,    **in_array()** 未设置参数的弱比较, 通过 **数组** 可以绕过 **md5()函数**。

**方法一:**
  利用``%00``截断绕过正则匹配,再利用``in_array()``的宽松比较得到flag。
  ```
  http://202.119.201.199:32790/?0ver=1%00adc&0ver1[]=1&0ver2[]=2
  ```

**方法二**
  只利用 ``in_array()`` 的宽松比较得到flag
```
http://202.119.201.199:32790/?0ver=01&0ver1[]=1&0ver2[]=2
```
<br>
### SimpleUpload签到
查看网页源代码发现有js前端过滤
``` JavaScript
 function checkFile() {
        var file = document.getElementsByName('upload_file')[0].value;
        if (file == null || file == "") {
            alert("请选择要上传的文件!");
            return false;
        }
        //定义允许上传的文件类型
        var allow_ext = ".jpg|.png|.gif";
        //提取上传文件的类型
        var ext_name = file.substring(file.lastIndexOf("."));
        //判断上传文件类型是否允许上传
        if (allow_ext.indexOf(ext_name) == -1) {
            var errMsg = "该文件不允许上传，请上传" + allow_ext + "类型的文件,当前文件类型为：" + ext_name;
            alert(errMsg);
            return false;
        }
    }

```
直接修改白名单,将 ``.php`` 加入到白名单中然后上传php文件得到flag
<br>
### 现代密码签到
根据给出的提示是用了``DES``加密,直接将密文粘贴解密网站进行解密得到flag

PS:感谢姚队的一直努力为我们队刷分,自己还是太菜了拖了团队的后腿。
路漫漫其修远兮，吾将上下而求索。