title: hexo快速搭建博客
date: '2018-04-26 07:01:37'
updated: '2018-04-26 07:01:37'
tags: [github, hexo]
permalink: /articles/2018/04/26/1575014355934.html
---
今天看室友搭好了自己的博客   有点冲动  就自己动手百度   

{%asset_img 11.jpg%}

忙了一天才搭出了自己的博客  



在搭建过程中遇到了一些小问题在这里总结一下

<!-- more -->

**首先安装git**

下载链接<https://git-scm.com/download/win>

安装git(全程next即可)



**安装node.js**

下载链接<https://nodejs.org/en/download/>

安装全程next

安装完毕后，检验Node.js是否安装成功，在cmd终端输入node -v

{% asset_img 1.JPG%}

检验npm是否安装成功,在cmd终端输入 npm -v:

{% asset_img 2.JPG%}



**Github创建个人仓库**

​	登录到GitHub,如果没有GitHub帐号，使用你的邮箱注册GitHub帐号：			<https://github.com/> 点击GitHub中的New repository创建新仓库，仓库名应该为：**用户		名**.github.io  这个**用户名**使用你的GitHub帐号名称代替，这是固定写法，比如我的仓		库名为：

​	{% asset_img 3.JPG%}



**Git与Github账号绑定**

鼠标右击打开Git Bash:

​	{%asset_img 4.jpg%}

设置user.name和user.email配置信息：

```git
git config --global user.name "你的GitHub用户名"
git config --global user.email "你的GitHub注册邮箱"
```

生成ssh密钥文件：

```
ssh-keygen -t rsa -C "你的GitHub注册邮箱"
```

然后直接三个回车即可，默认不需要设置密码
然后找到生成的.ssh的文件夹中的id_rsa.pub密钥，将内容全部复制

{%asset_img 5.JPG%}

打开[GitHub_Settings_keys](https://link.zhihu.com/?target=https%3A//github.com/settings/keys) 页面，新建new SSH Key

{%asset_img 6.jpg%}

Title为标题，任意填即可，将刚刚复制的id_rsa.pub内容粘贴进去，最后点击Add SSH key。
在Git Bash中检测GitHub公钥设置是否成功(右键点击.ssh文件用Git Bash打开)，输入 ssh git@github.com ：

{% asset_img 7.jpg%}

如上则说明成功。这里之所以设置GitHub密钥原因是，通过非对称加密的公钥与私钥来完成加密，公钥放置在GitHub上，私钥放置在自己的电脑里。GitHub要求每次推送代码都是合法用户，所以每次推送都需要输入账号密码验证推送用户是否是合法用户，为了省去每次输入密码的步骤，采用了ssh，当你推送的时候，git就会匹配你的私钥跟GitHub上面的公钥是否是配对的，若是匹配就认为你是合法用户，则允许推送。这样可以保证每次的推送都是正确合法的。



**安装Hexo**

Hexo就是我们的个人博客网站的框架， 这里需要自己在电脑常里创建一个文件夹，可以命名为Blog，Hexo框架与以后你自己发布的网页都在这个文件夹中。创建好后，进入文件夹中，按住shift键，右击鼠标点击Git Bash

使用npm命令安装Hexo,输入:

```
npm install -g hexo
```



安装完成后，初始化我们的博客，输入：

```
hexo init blog
```

注意，这里的命令都是作用在刚刚创建的Blog文件夹中。

为了检测我们的网站雏形，分别按顺序输入以下三条命令：

```
npm install

hexo g

hexo s
```

这些命令在后面作介绍，完成后，打开浏览器输入地址：

<localhost:4000>

现在来介绍常用的Hexo 命令

```
npm install hexo -g     #安装Hexo

npm update hexo -g    #升级 

hexo init    #初始化博客

命令简写

hexo n  "我的博客" == hexo new  "我的博客"   #新建文章

hexo g == hexo generate   #生成

hexo s == hexo server   #启动服务预览

hexo d == hexo deploy   #部署

hexo server     #Hexo会监视文件变动并自动更新，无须重启服务器

hexo server -s    #静态模式

hexo server -p 5000     #更改端口

hexo server -i 192.168.1.1     #自定义 IP

hexo clean     #清除缓存，若是网页正常情况下可以忽略这条命令

```



刚刚的三个命令依次是新建一篇博客文章、生成网页、在本地预览的操作。

**推送网站**

上面只是在本地预览，接下来要做的就是就是推送网站，也就是发布网站，让我们的网站可以被更多的人访问。在设置之前，需要解释一个概念，在blog根目录里的_config.yml文件称为**站点**配置文件，如下图

{%asset_img 8.JPG%}

下一步将我们的Hexo与GitHub关联起来，打开站点的配置文件_config.yml，翻到最后修改为：

```
deploy: 

type: git

repo: 这里填入你之前在GitHub上创建仓库的完整路径，记得加上 .git

branch: master

```

参考如下：

{%asset_img 9.JPG%}

保存站点配置文件。

其实就是给hexo d 这个命令做相应的配置，让hexo知道你要把blog部署在哪个位置，很显然，我们部署在我们GitHub的仓库里。最后安装Git部署插件，输入命令：

```
npm install hexo-deployer-git --save
```

最后执行

```
hexo clean && hexo g && hexo d
```

其实第三条的 hexo d 就是部署网站命令，d是deploy的缩写。完成后，打开浏览器，在地址栏输入你的放置个人网站的仓库路径，即 [xxxx.github.io](link.zhihu.com/?target=http%3A//xxxx.github.io)

{%asset_img 10.JPG%}



​你的博客已经上线,随时可以起飞           

{%asset_img 13.jpg%}





​                                                                     教程参考:<https://zhuanlan.zhihu.com/p/26625249>