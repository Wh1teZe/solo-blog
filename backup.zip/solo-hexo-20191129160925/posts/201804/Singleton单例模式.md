title: Singleton(单例)模式
date: '2018-04-27 05:03:28'
updated: '2018-04-27 05:03:28'
tags: [-Java, -设计模式]
permalink: /articles/2018/04/27/1575014359970.html
---
最近苦于研究博客主题（前端水好深啊），没怎么学习Java知识，感觉自己要颓废了

{% asset_img 1.jpg %}

今天get到了单例模式,所以写个博客总结一下

<!-- more -->

# 浅谈单例

## 实现单例模式有两种方式:

▲饿汉式：将类的构造方式私有化, 用一个私有的类的变量instance保存类的实例，在加载类时，创建类的实例，并将实例赋给instance；再提供一个私有的静态方法getInstance，用于获取类的唯一实例，该方法直接返回instance。

▲懒汉式（加强版）： 将类的构造方式私有化，用一个私有的类变量instance保存类的实例，在加载类时，将null赋给instance；再提供一个公有的静态方法getInstance，用于获取类的唯一实例，该方法首先判断instance是否为null，如果为null，则创建实例对象；否则，直接返回instance。

  两种方式的区别: 前者在类被加载时，类的唯一实例被创建；后者在第一次调用getInstance方法时，类的唯一实例被创建。但在使用后一种方法实现单例模式时，需要在getInstance方法的声明中使用synchronized（同步）关键字，保证某一时刻只能一个线程调用此方法。

## 实例演示

###  饿汉式

```java
package com.test.Singleton;

public class SingletonA {
    private static int id = 1;   // 私有属性
    private static SingletonA instance = new SingletonA();//StringletonA的唯一实例
    
    //将构造方法私有化,防止外界构造SingletonA实例
    private SingletonA (){}
    //获取SingletonA的实例
    public static SingletonA getInstance(){
        return instance;
    }
    /**
     * 获取实例的id, synchronized关键字表示该方法的线程同步的
     * 即任一时刻最多只能有一个线程进入该方法
     * @return 返回id属性
     */
    public synchronized int getId() {
    	return id;
    }
    //将实现的id加1
    public synchronized void nextID() {
    	id++;
    }
}
```



<br>

### 懒汉式

```java
package com.test.Singleton;

public class SingletonB {
		private static int id = 1; //私有属性
		private static SingletonB instance = null;  //SingletonB的唯一实例
		
		//将构造方法私有化, 防止外界构造SingletonB实例
		private SingletonB() {}
		//获取SingletonB的唯一实例,使用synchronized关键字保证某一时刻只有一个线程调用方法
		public static synchronized SingletonB getInstance() {
			//如果instance为空,则创建一个新的SingletonB实例; 否则, 返回已有的实例
			if(instance == null) {
				instance = new SingletonB();
			}
			return instance;
		}
		public synchronized int getId() {
			return id;
		}
		public synchronized void nextID() {
			id++;
		}
}
```

###  <br>

### 运用SingletonTest类进行测试

```java
package com.test.Singleton;

public class SingletonTest {

/**
 * 模式名称: 单例模式
 * 模式特征: 只能创建该类的一个实例
 * 模式用途: 提供一个全局共享类实例
 */
		
	public static void main(String[] args) {
		
		SingletonA a1 = SingletonA.getInstance();
		SingletonA a2 = SingletonA.getInstance();
		System.out.println("用SingletonA实现单例模式");
		System.out.println("调用nextID方法前");
		System.out.println("a1.id=" + a1.getId());
		System.out.println("a2.id=" + a2.getId());
		a1.nextID();
		System.out.println("调用nextID方法后");
		System.out.println("a1.id=" + a1.getId());
		System.out.println("a2.id=" + a2.getId());
		
		SingletonB b1 = SingletonB.getInstance();
		SingletonB b2 = SingletonB.getInstance();
		System.out.println("--------------------------------------");
		System.out.println("用SingletonB实现单例模式");
		System.out.println("调用nextID方法前");
		System.out.println("b1.id=" + b1.getId());
		System.out.println("b2.id=" + b2.getId());
		b1.nextID();
		System.out.println("调用nextID方法后");
		System.out.println("b1.id=" + b1.getId());
		System.out.println("b2.id=" + b2.getId());
		
	}
}
```

#### 输出结果为:

{% asset_img 2.JPG%}

## 分析:

1. 单例模式的实现方法是将构造方法私有，以防止外界通过调用构造方法创建累的对象。将类的唯一对象保存为静态私有属性，然后提供一个静态公有方法获取该唯一对象，可以保证每次返回的都是同一个对象。
2. SingletonA类和SingletonB类都是实现了单例模式，区别是前者在类被加载的时候就创建类的唯一对象，而后者是在第一次调用getInstance方法的时才创建类的唯一实例，因此也被称为“lazyinitialization”（延迟初始化）
3. 在SIngletonB类中，getInstance方法声明中使用了synchronized（同步）关键字，以保证同一时刻只有一个线程进入该方法，这样就保证了只会创建一个对象。