title: Mysql基本操作
date: '2019-08-19 00:32:11'
updated: '2019-11-29 16:35:19'
tags: [Mysql]
permalink: /articles/2019/08/19/1575014356805.html
---
![](https://img.hacpai.com/bing/20181211.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# Mysql操作基础

<!-- more -->

## 创建数据库和表

### 数据库操作
#### 创建数据库
```sql
create database test;
```

#### 查看数据库
```sql
show databases;
```
#### 删除数据库
```sql
drop database test;
```

### 数据表操作
#### 创建数据表
  ```SQL
  CREATE TABLE test1(
    id INT NOT NULL,
    name VARCHAR(20),
    age INT,
    sex char(1) DEFAULT 'm',
    score DOUBLE NOT NULL
    );
  ```
  数据表创建字段约束定义语法为：
  ```sql
  列级别：
  CREATE TABLE table_name(column_name data_type
　  　[ [NOT NULL] | [UNIQUE [KEY] | PRIMARY KEY]
　  　|CHECK(expr)],…)

  表级别：
  CREATE TABLE table_name(
　  　column_name  data_type [NOT NULL],
     　　column_name data_type [not null],…,
　  　[CONSTRAINT constraint_name] PRIMARY KEY (col_name,...)
　　  |[CONSTRAINT constraint_name] unique (col_name,...)
　　  |[CONSTRAINT constraint_name] foreign KEY (col_name) REFERENCES tbl_name (index_col_name)
　　  |check(expr)
  ```
  **表的约束**

  ![5.png](https://i.loli.net/2019/08/06/FrETHi8MI17Xdem.png)

#### 删除数据表
   ```sql
   DROP TABLE table_name;
   ```
   **注意**:
   删除没有被关联的表：直接DROP即可。
   删除被其他表关联的父表：
   方法一：先删除子表，再删除父表。
   方法二：删除父表的外键约束，再删除该表。

#### 查看表结构
1) 查看表基本结构语句 `DESCRIBE`

  ```sql
  DESC table_name;
  ```
  例如：
  ```sql
  mysql> DESC test1;
  +-------+-------------+------+-----+---------+-------+
  | Field | Type        | Null | Key | Default | Extra |
  +-------+-------------+------+-----+---------+-------+
  | id    | int(11)     | NO   | PRI | NULL    |       |
  | name  | varchar(20) | YES  |     | NULL    |       |
  | age   | int(11)     | YES  |     | NULL    |       |
  | sex   | char(1)     | YES  |     | m       |       |
  | score | double      | NO   |     | NULL    |       |
  +-------+-------------+------+-----+---------+-------+
  5 rows in set (0.00 sec)
  ```
2) 查看表详细结构语句 `SHOW CREATE TABLE`

  ```sql
  SHOW CREATE TABLE 表名;
  ```
  例如:
  ```sql
  mysql> SHOW CREATE TABLE test1;
  +-------+--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
  | Table | Create Table                                                                                                                                                                                                                         |
  +-------+--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
  | test1 | CREATE TABLE `test1` (
    `id` int(11) NOT NULL,
    `name` varchar(20) DEFAULT NULL,
    `age` int(11) DEFAULT NULL,
    `sex` char(1) DEFAULT 'm',
    `score` double NOT NULL,
    PRIMARY KEY (`id`)
  ) ENGINE=InnoDB DEFAULT CHARSET=latin1 |
  +-------+--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
  1 row in set (0.00 sec)

  ```
#### 修改表
1) 修改表名
  ```sql
  ALTER TABLE 旧表名 RENAME 新表名;
  ```
  例如：
  ```sql
  mysql> ALTER TABLE test1 RENAME test2;
  Query OK, 0 rows affected (0.01 sec)

  mysql> show tables;
  +----------------+
  | Tables_in_test |
  +----------------+
  | test2          |
  +----------------+
  1 row in set (0.00 sec)

  ```
2) 修改字段的数据类型
  ```sql
  ALTER TABLE 表名 MODIFY 属性名 数据类型;
  ```
  例如：
  ```sql
  mysql> DESC test1;
+-------+-------------+------+-----+---------+-------+
| Field | Type        | Null | Key | Default | Extra |
+-------+-------------+------+-----+---------+-------+
| id    | int(11)     | NO   | PRI | NULL    |       |
| name  | varchar(20) | YES  |     | NULL    |       |
| age   | int(11)     | YES  |     | NULL    |       |
| sex   | char(1)     | YES  |     | m       |       |
| score | double      | NO   |     | NULL    |       |
+-------+-------------+------+-----+---------+-------+
5 rows in set (0.00 sec)

mysql> ALTER TABLE test1 MODIFY name varchar(30);
Query OK, 0 rows affected (0.00 sec)
Records: 0  Duplicates: 0  Warnings: 0

mysql> DESC test1;
+-------+-------------+------+-----+---------+-------+
| Field | Type        | Null | Key | Default | Extra |
+-------+-------------+------+-----+---------+-------+
| id    | int(11)     | NO   | PRI | NULL    |       |
| name  | varchar(30) | YES  |     | NULL    |       |
| age   | int(11)     | YES  |     | NULL    |       |
| sex   | char(1)     | YES  |     | m       |       |
| score | double      | NO   |     | NULL    |       |
+-------+-------------+------+-----+---------+-------+
5 rows in set (0.00 sec)
  ```
3) 修改字段名
  ```sql
  ALTER TABLE 表名 CHANGE 旧属性名 新属性名 新数据类型;
  ```
  例如：
  ```sql
  mysql> DESC test1;
+-------+-------------+------+-----+---------+-------+
| Field | Type        | Null | Key | Default | Extra |
+-------+-------------+------+-----+---------+-------+
| id    | int(11)     | NO   | PRI | NULL    |       |
| name  | varchar(30) | YES  |     | NULL    |       |
| age   | int(11)     | YES  |     | NULL    |       |
| sex   | char(1)     | YES  |     | m       |       |
| score | double      | NO   |     | NULL    |       |
+-------+-------------+------+-----+---------+-------+
5 rows in set (0.00 sec)

mysql> ALTER TABLE test1 CHANGE name stu_name varchar(40);
Query OK, 0 rows affected (0.00 sec)
Records: 0  Duplicates: 0  Warnings: 0

mysql> DESC test1;
+----------+-------------+------+-----+---------+-------+
| Field    | Type        | Null | Key | Default | Extra |
+----------+-------------+------+-----+---------+-------+
| id       | int(11)     | NO   | PRI | NULL    |       |
| stu_name | varchar(40) | YES  |     | NULL    |       |
| age      | int(11)     | YES  |     | NULL    |       |
| sex      | char(1)     | YES  |     | m       |       |
| score    | double      | NO   |     | NULL    |       |
+----------+-------------+------+-----+---------+-------+
5 rows in set (0.00 sec)

  ```
4) 增加字段
  ```sql
  ALTER TABLE 表名 ADD 属性名1 数据类型 [完整性约束条件] [FIRST | AFTER 属性名2];
  ```
  例如：
  ```sql
  mysql> ALTER TABLE test1 ADD teacher_name varchar(20) NOT NULL AFTER id;
Query OK, 0 rows affected (0.03 sec)
Records: 0  Duplicates: 0  Warnings: 0

mysql> DESC test1;
+--------------+-------------+------+-----+---------+-------+
| Field        | Type        | Null | Key | Default | Extra |
+--------------+-------------+------+-----+---------+-------+
| id           | int(11)     | NO   | PRI | NULL    |       |
| teacher_name | varchar(20) | NO   |     | NULL    |       |
| stu_name     | varchar(40) | YES  |     | NULL    |       |
| age          | int(11)     | YES  |     | NULL    |       |
| sex          | char(1)     | YES  |     | m       |       |
| score        | double      | NO   |     | NULL    |       |
+--------------+-------------+------+-----+---------+-------+
6 rows in set (0.00 sec)
  ```
5) 删除字段
  ```sql
  ALTER TABLE 表名 DROP 属性名;
  ```
  例如：
  ```sql
  mysql> ALTER TABLE test1 DROP teacher_name;
Query OK, 0 rows affected (0.04 sec)
Records: 0  Duplicates: 0  Warnings: 0

mysql> DESC test1;
+----------+-------------+------+-----+---------+-------+
| Field    | Type        | Null | Key | Default | Extra |
+----------+-------------+------+-----+---------+-------+
| id       | int(11)     | NO   | PRI | NULL    |       |
| stu_name | varchar(40) | YES  |     | NULL    |       |
| age      | int(11)     | YES  |     | NULL    |       |
| sex      | char(1)     | YES  |     | m       |       |
| score    | double      | NO   |     | NULL    |       |
+----------+-------------+------+-----+---------+-------+
5 rows in set (0.00 sec)

  ```

## 数据表的增删改查

### 添加数据

#### 为表中所有字段添加数据
1) 指定所有字段
```sql
INSERT INTO 表名（字段名1，字段名2，…）

　　　　　　   VALUES（值1，值2，…）；
```
例如:
```sql
mysql> INSERT INTO test1 (id,stu_name,age,sex,score)
    -> VALUES(2,'John',19,'m',98);
Query OK, 1 row affected (0.00 sec)

mysql> select * from test1;
+----+----------+------+------+-------+
| id | stu_name | age  | sex  | score |
+----+----------+------+------+-------+
|  1 | Tony     |   16 | m    |    80 |
|  2 | John     |   19 | m    |    98 |
+----+----------+------+------+-------+
2 rows in set (0.00 sec)
```
2) 不指定字段
若不指定字段名，则添加的值的顺序应和字段在表中的顺序完全一致。
```sql
INSERT INTO 表名 VALUES(值11，值2，…);
```
例如:
```sql
mysql> INSERT INTO test1 VALUES(3,'zhangsan',20,'w',90);
Query OK, 1 row affected (0.00 sec)

mysql> select * from test1;
+----+----------+------+------+-------+
| id | stu_name | age  | sex  | score |
+----+----------+------+------+-------+
|  1 | Tony     |   16 | m    |    80 |
|  2 | John     |   19 | m    |    98 |
|  3 | zhangsan |   20 | w    |    90 |
+----+----------+------+------+-------+
3 rows in set (0.00 sec)

```

#### 为表的指定字段添加数据
为指定字段添加数据，即只向部分字段添加值，而其他字段的值为表定义时的默认值。
```sql
INSERT INTO 表名（字段1，字段2，…）

　　   VALUES(值1，值2，…);
```
例如：
```sql
mysql> INSERT INTO test1 (id,stu_name,age,score)
    -> VALUES (4,'lisi',18,76);
Query OK, 1 row affected (0.00 sec)

mysql> select * from test1;
+----+----------+------+------+-------+
| id | stu_name | age  | sex  | score |
+----+----------+------+------+-------+
|  1 | Tony     |   16 | m    |    80 |
|  2 | John     |   19 | m    |    98 |
|  3 | zhangsan |   20 | w    |    90 |
|  4 | lisi     |   18 | m    |    76 |
+----+----------+------+------+-------+
4 rows in set (0.00 sec)
```

### 删除数据

#### 删除部分数据
即删除指定的部分数据，需要使用WHERE子句来指定删除记录的条件。
例如：
删除test1表中id为2的数据。
```sql
mysql> DELETE FROM test1 WHERE id=2;
Query OK, 1 row affected (0.00 sec)

mysql> select * from test1;
+----+----------+------+------+-------+
| id | stu_name | age  | sex  | score |
+----+----------+------+------+-------+
|  1 | Tony     |   16 | m    |    80 |
|  3 | zhangsan |   20 | w    |    90 |
|  4 | lisi     |   18 | m    |    76 |
+----+----------+------+------+-------+
3 rows in set (0.00 sec)
```
#### 删除全部数据


### 更新数据
更新数据指对表中现存的数据进行修改。
```sql
UPDATE 表名
　　　　　　SET 字段名1=值1，[ ，字段名2=值2，…]
　　　　　　[ WHERE 条件表达式 ]
```
#### 更新部分数据
指更新指定表中的指定记录，使用WHERE 子句来指定。
```sql
mysql> UPDATE test1 SET stu_name="wangmazi",score=50
    -> WHERE id=1;
Query OK, 1 row affected (0.00 sec)
Rows matched: 1  Changed: 1  Warnings: 0

mysql> select * from test1;
+----+----------+------+------+-------+
| id | stu_name | age  | sex  | score |
+----+----------+------+------+-------+
|  1 | wangmazi |   16 | m    |    50 |
|  3 | zhangsan |   20 | w    |    90 |
|  4 | lisi     |   18 | m    |    76 |
+----+----------+------+------+-------+
3 rows in set (0.00 sec)
```

#### 更新全部数据
例如，将score字段更新为80:
```sql
mysql> UPDATE test1
    -> SET score=80;
Query OK, 3 rows affected (0.00 sec)
Rows matched: 3  Changed: 3  Warnings: 0

mysql> select * from test1;
+----+----------+------+------+-------+
| id | stu_name | age  | sex  | score |
+----+----------+------+------+-------+
|  1 | wangmazi |   16 | m    |    80 |
|  3 | zhangsan |   20 | w    |    80 |
|  4 | lisi     |   18 | m    |    80 |
+----+----------+------+------+-------+
3 rows in set (0.00 sec)
```
### 查询数据

#### 简单查询

##### 查询所有字段
在SELECT语句中使用（‘ * ’）通配符代替所有字段

```sql
SELECT * FROM 表名；
```

##### 查询指定的部分字段

```sql
SELECT 字段名1，字段名2，… FROM 表名；
```
例如查询表中name和sex字段：

```sql
mysql> SELECT stu_name,sex FROM test1;
+----------+------+
| stu_name | sex  |
+----------+------+
| wangmazi | m    |
| Tony     | m    |
| zhangsan | w    |
| lisi     | m    |
| wangwu   | w    |
| wuzhu    | m    |
+----------+------+
6 rows in set (0.00 sec)
```

#### 按条件查询

##### 带关系运算符的查询

使用`where`关键字来删选更精确的数据

```sql
SELECT 字段名1，字段名2，…
 　　　FROM 表名
　　    WHERE 条件表达式
```

在WHERE子句中可以使用如下关系运算符：

|关系运算符|说明|
|:--:|:--:|
|=|等于|
|<>|不等于|
|!=|不等于|
|<|小于|
|<=|小于等于|
|>|大于|
|>=|大于等于|

例如查询表中id为4的学生信息:

```sql
mysql> SELECT * FROM test1 WHERE id=4;
+----+----------+------+------+-------+
| id | stu_name | age  | sex  | score |
+----+----------+------+------+-------+
|  4 | lisi     |   18 | m    |    76 |
+----+----------+------+------+-------+
1 row in set (0.00 sec)
```

##### 带IN关键字的查询

IN关键字用于判断某个字段的值是否在指定集合中，若在，则该字段所在的记录将会被查询出来.

```sql
SELECT * | 字段名1，字段名2，…
　　　FROM 表名
　　　WHERE 字段名 [ NOT ]  IN （元素1，元素2，…）
```
例如查询表中id为1,2,3的数据

```sql
mysql> SELECT * FROM test1 WHERE id IN (1,2,3);
+----+----------+------+------+-------+
| id | stu_name | age  | sex  | score |
+----+----------+------+------+-------+
|  1 | wangmazi |   16 | m    |    80 |
|  2 | Tony     |   30 | m    |    99 |
|  3 | zhangsan |   20 | w    |    90 |
+----+----------+------+------+-------+
3 rows in set (0.01 sec)
```

**注意**：NOT IN 与 IN 相反，查询的是不在指定范围内的记录。

#####  带 BETWEEN AND  关键字的查询

BETWEEN AND 用于判断某个字段的值是否在指定范围之内，若在，则该字段所在的记录会被查询出来，反之不会。

```sql
SELECT * | { 字段名1，字段名2，… }
　　　FROM  表名
　　    WHERE 字段名 [ NOT ] BETWEEN  值1  AND  值2；
```
例如查询test1表中id值在2-5之间的学生

```sql
mysql> SELECT * FROM test1 WHERE id BETWEEN 2 AND 5;
+----+----------+------+------+-------+
| id | stu_name | age  | sex  | score |
+----+----------+------+------+-------+
|  2 | Tony     |   30 | m    |    99 |
|  3 | zhangsan |   20 | w    |    90 |
|  4 | lisi     |   18 | m    |    76 |
|  5 | wangwu   |   26 | w    |    80 |
+----+----------+------+------+-------+
4 rows in set (0.00 sec)
```

##### 带 DISTINCT 关键字的查询

很多表中某些字段的数据存在重复的值，可以使用DISTINCT关键字来过滤重复的值，只保留一个值。

```sql
SELECT DISTINCT 字段名 FROM 表名;
```
例如查询test1表中sex字段的值：

```sql
mysql> SELECT DISTINCT sex FROM test1;
+------+
| sex  |
+------+
| m    |
| w    |
+------+
2 rows in set (0.00 sec)
```
**注意**：DISTINCT 关键字还可作用于多个字段，则只有多个字段的值都完全相同时才会被认作是重复记录。

##### 带 LIKE 关键字的查询

```sql
SELECT * | 字段名1，字段名2，…
　　　FROM 表名
　　　WHERE 字段名 [ NOT ] LIKE ‘匹配字符串’;
```

1. **百分号（%）通配符**

    匹配任意长度的字符串，包括空字符串。例如，字符串“ c% ”匹配以字符 c 开始，任意长度的字符串，如“ ct  ”，“ cut ”，“ current ”等；字符串“ c%g ”表示以字符 c 开始，以 g 结尾的字符串；字符串“ %y% ”表示包含字符“ y ”的字符串，无论“ y ”在字符串的什么位置。

  例如查询test1表中那么字段以字符“w”开头的学生：

  ```sql
  mysql> SELECT * FROM test1 WHERE stu_name LIKE "w%";
+----+----------+------+------+-------+
| id | stu_name | age  | sex  | score |
+----+----------+------+------+-------+
|  1 | wangmazi |   16 | m    |    80 |
|  5 | wangwu   |   26 | w    |    80 |
|  6 | wuzhu    |   50 | m    |    84 |
+----+----------+------+------+-------+
3 rows in set (0.00 sec)
  ```

1. **下划线（_）通配符**

  下划线通配符只匹配单个字符，若要匹配多个字符，需要使用多个下划线通配符。例如，字符串“ cu_ ”匹配以字符串“ cu ”开始，长度为3的字符，如“ cut ”，“ cup ”；字符串“ c__l”匹配在“ c ”和“ l ”之间包含两个字符的字符串，如“ cool ”。需要注意的是，连续的“_”之间不能有空格，例如“M_ _QL”只能匹配“My SQL”，不能匹配“MySQL”。

  例如查询test1表中name字段值以“wan”开始，“wu”结束。

  ```sql
  mysql> SELECT * FROM test1 WHERE stu_name LIKE 'wan_wu';
+----+----------+------+------+-------+
| id | stu_name | age  | sex  | score |
+----+----------+------+------+-------+
|  5 | wangwu   |   26 | w    |    80 |
+----+----------+------+------+-------+
1 row in set (0.00 sec)
  ```

##### 带 AND 关键字的多条件查询

在使用SELECT语句查询数据时，优势为了使查询结果更加精确，可以使用多个查询条件，如使用 AND 关键字可以连接两个或多个查询条件。

```sql
SELECT * | 字段名1，字段名2，…
　　　FROM 表名
　　　WHERE 条件表达式1 AND 条件表达式2 [ … AND 条件表达式 n ];
```

##### 带 OR 关键字的多条件查询

与 AND 关键字不同，OR 关键字只要满足任意一个条件就会被查询出来

```sql
SELECT * | 字段名1，字段名2，…
　　　FROM 表名
　　　WHERE 条件表达式1 OR 条件表达式2 [ … OR 条件表达式 n ];
```
**注意**：OR 和 AND 一起使用的时候，AND 的优先级高于
OR，因此二者一起使用时，会先运算 AND 两边的表达式，再运算 OR 两边的表达式。

#### 高级查询

##### 聚合函数

|函数名称|作用|
|:--:|:--:|
|COUNT()|返回某列的行数|
|SUM()|返回某列值的和|
|AVG()|返回某列的平均值|
|MAX()|返回某列的最大值|
|MIN()|返回某列的最小值|

1. **COUNT()函数：统计记录的条数**

  ```sql
  SELECT COUNT(*) FROM 表名;
  ```
1. **SUM()函数：求出表中某个字段所有值的总和**

  ```sql
  SELECT  SUM(字段名) FROM 表名；
  ```
1. **AVG()函数：求出表中某个字段所有值的平均值**

  ```sql
  SELECT AVG(字段名) FROM 表名；
  ```
1. **MAX()函数：求出表中某个字段所有值的最大值**

  ```sql
  SELECT MAX(字段名) FROM 表名；
  ```
1. **MIN()函数：求出表中某个字段所有值的最小值**

  ```sql
  SELECT MIN(字段名) FROM 表名；
  ```

##### 对查询结果进行排序

使用`ORDER BY`对数据进行排序

```sql
SELECT 字段名1，字段名2，…
　　　FROM 表名
　　　ORDER BY 字段名1 [ ASC | DESC ],字段名2 [ ASC | DESC ]…
```
**注意：**在该语法中指定的字段名是对查询结果进行排序的依据，`ASC`表示升序排列，`DESC` 表示降序排列，默认情况是升序排列。
例如查出test1表中的所有数据，并按照score进行升序排序：

```sql
mysql> SELECT * FROM test1
    -> ORDER BY score ASC;
+----+----------+------+------+-------+
| id | stu_name | age  | sex  | score |
+----+----------+------+------+-------+
|  4 | lisi     |   18 | m    |    76 |
|  1 | wangmazi |   16 | m    |    80 |
|  5 | wangwu   |   26 | w    |    80 |
|  6 | wuzhu    |   50 | m    |    84 |
|  3 | zhangsan |   20 | w    |    90 |
|  2 | Tony     |   30 | m    |    99 |
+----+----------+------+------+-------+
6 rows in set (0.01 sec)
```

##### 分组查询

在对表中数据进行统计的时候，可以使用GROUP BY
按某个字段或者多个字段进行分组，字段中值相同的为一组。

```sql
SELECT  字段名1，字段名2，…
　　　FROM 表名
　　　GROUP BY 字段名1，字段名2，… [ HAVING 条件表达式 ];
```

###### 单独使用GROUP BY进行分组

单独使用GROUP BY 关键字，查询的是每个分组中的一条记录。

例如查询test1表中的数据，按照sex字段进行分组：

```sql
mysql> SELECT * FROM test1 GROUP BY sex;
+----+----------+------+------+-------+
| id | stu_name | age  | sex  | score |
+----+----------+------+------+-------+
|  1 | wangmazi |   16 | m    |    80 |
|  3 | zhangsan |   20 | w    |    90 |
+----+----------+------+------+-------+
2 rows in set (0.00 sec)
```

###### GROUP BY 和聚合函数一起使用

GROUP BY 和聚合函数一起使用，可以统计出某个或者某些字段在一个分组中的最大值、最小值、平均值等。

例如将test1表按照sex字段进行分组查询，计算出每组共有多少人。

```sql
mysql> SELECT COUNT(*),sex FROM test1 GROUP BY sex;
+----------+------+
| COUNT(*) | sex  |
+----------+------+
|        4 | m    |
|        2 | w    |
+----------+------+
2 rows in set (0.00 sec)
```

###### GROUP BY 和 HAVING 关键字一起使用

 HAVING关键字和WHERE关键字的作用相同，区别在于HAVING 关键字可以跟聚合函数，而WHERE 关键字不能。通常HAVING 关键字都和GROUP BY一起使用，用于对分组后的结果进行过滤。

例如将test1表按照sex字段进行分组查询，查询出score字段值之和小于300的分组。

```sql
mysql> SELECT SUM(score),sex FROM test1
    -> GROUP BY sex
    -> HAVING SUM(score)<300;
+------------+------+
| SUM(score) | sex  |
+------------+------+
|        170 | w    |
+------------+------+
1 row in set (0.00 sec)
```

##### 使用 LIMIT 限制查询结果的数量

```sql
SELECT 字段名2，字段名2，…
　　　FROM 表名
　　　LIMIT [ OFFSET ,] 记录数
```
在此语法中，LIMIT 后面可以跟两个参数，第一个参数“ OFFSET ”表示偏移量，如果偏移量为0，则从查询结果的第一条记录开始，偏移量为1则从查询结果中的第二条记录开始，以此类推。OFFSET为可选值，默认值为0，第二个参数“记录数”表示指定返回查询记录的条数。

例如查询test1表中的前四条记录：

```sql
mysql> SELECT * FROM test1 LIMIT 4;
+----+----------+------+------+-------+
| id | stu_name | age  | sex  | score |
+----+----------+------+------+-------+
|  1 | wangmazi |   16 | m    |    80 |
|  2 | Tony     |   30 | m    |    99 |
|  3 | zhangsan |   20 | w    |    90 |
|  4 | lisi     |   18 | m    |    76 |
+----+----------+------+------+-------+
4 rows in set (0.00 sec)
```

## [附加]MySQL字段类型

MySQL的列类型主要有三种：数字、字串和日期。

### 数字列类型

　数字列类型用于储存各种数字数据，如价格、年龄或者数量。数字列类型主要分为两种：整数型和浮点型。所有的数字列类型都允许有两个选项：UNSIGNED和ZEROFILL。选择UNSIGNED的列不允许有负数，选择了ZEROFILL的列会为数值添加零。下面是MySQL中可用的数字列类型

- TINYINT——一个微小的整数，支持 -128到127(SIGNED)，0到255(UNSIGNED)，需要1个字节存储
- BIT——同TINYINT(1)
- BOOL——同TINYINT(1)
- SMALLINT——一个小整数，支持 -32768到32767(SIGNED)，0到65535(UNSIGNED)，需要2个字节存储 MEDIUMINT——一个中等整数，支持 -8388608到8388607(SIGNED)，0到16777215(UNSIGNED)，需要3个字节存储
- INT——一个整数，支持 -2147493648到2147493647(SIGNED)，0到4294967295(UNSIGNED)，需要4个字节存储
- INTEGER——同INT
- BIGINT——一个大整数，支持 -9223372036854775808到9223372036854775807(SIGNED)，0到18446744073709551615(UNSIGNED)，需要8个字节存储
- FLOAT(precision)——一个浮点数。precision<=24用于单精度浮点数；precision在25和53之间，用于又精度浮点数。FLOAT(X)与相诮的FLOAT和DOUBLE类型有差相同的范围，但是没有定义显示尺寸和小数位数。在MySQL3.23之前，这不是一个真的浮点值，且总是有两位小数。MySQL中的所有计算都用双精度，所以这会带来一些意想不到的问题。
- FLOAT——一个小的菜单精度浮点数。支持 -3.402823466E+38到-1.175494351E-38，0和1.175494351E-38 to 3.402823466E+38，需要4个字节存储。如果是UNSIGNED，正数的范围保持不变，但负数是不允许的。
- DOUBLE——一个双精度浮点数。支持 -1.7976931348623157E+308到-2.2250738585072014E-308，0和2.2250738585072014E-308到1.7976931348623157E+308。如果是FLOAT，UNSIGNED不会改变正数范围，但负数是不允许的。
- DOUBLE PRECISION——同DOUBLE
- REAL——同DOUBLE
- DECIMAL——将一个数像字符串那样存储，每个字符占一个字节
- DEC——同DECIMAL
- NUMERIC——同DECIMAL

### 字符串列类型
　　字符串列类型用于存储任何类型的字符数据，如名字、地址或者报纸文章。下面是MySQL中可用的字符串列类型
- CHAR——字符。固定长度的字串，在右边补齐空格，达到指定的长度。支持从0到155个字符。搜索值时，后缀的空格将被删除。
- VARCHAR——可变长的字符。一个可变长度的字串，其中的后缀空格在存储值时被删除。支持从0到255字符
- TINYBLOB——微小的二进制对象。支持255个字符。需要长度+1字节的存储。与TINYTEXT一样，只不过搜索时是区分大小写的。(0.25KB)
- TINYTEXT——支持255个字符。要求长度+1字节的存储。与TINYBLOB一样，只不过搜索时会忽略大小写。(0.25KB)
- BLOB——二进制对象。支持65535个字符。需要长度+2字节的存储。 (64KB)
- TEXT——支持65535个字符。要求长度+2字节的存储。 (64KB)
- MEDIUMBLOB——中等大小的二进制对象。支持16777215个字符。需要长度+3字节的存储。 (16M)
- MEDIUMTEXT——支持16777215个字符。需要长度+3字节的存储。 (16M)
- LONGBLOB——大的的二进制对象。支持4294967295个字符。需要长度+4字节的存储。 (4G)
- LONGTEXT——支持4294967295个字符。需要长度+4字节的存储。(4G)
- ENUM——枚举。只能有一个指定的值，即NULL或""，最大有65535个值
- SET——一个集合。可以有0到64个值，均来自于指定清单

#### 日期和时间列类型

　　日期和时间列类型用于处理时间数据，可以存储当日的时间或出生日期这样的数据。格式的规定：Y表示年、M（前M）表示月、D表示日、H表示小时、M（后M）表示分钟、S表示秒。下面是MySQL中可用的日期和时间列类型

- DATETIME——格式：'YYYY-MM-DD HH:MM:SS'，范围：'1000-01-01 00:00:00'到'9999-12-31 23:59:59'
- DATE——格式：'YYYY-MM-DD'，范围：'1000-01-01'到'9999-12-31'
- TIMESTAMP——格式：'YYYYMMDDHHMMSS'、'YYMMDDHHMMSS'、'YYYYMMDD'、'YYMMDD'，范围：'1970-01-01 00:00:00'到'2037-01-01 00:00:00'
- TIME——格式：'HH:MM:SS'
- YEAR——格式：'YYYY，范围：'1901'到'2155'


参考博客：

[[备忘]MySQL字段类型](https://www.cnblogs.com/szw/archive/2011/03/16/1986410.html)
[MySQL之增删改查](https://www.cnblogs.com/heyangblog/p/7624645.html)
[MySQL-数据库增删改查](https://www.cnblogs.com/renshaoqi/p/10186962.html)
