title: BuuCTF刷题之旅之WarmUp
date: '2019-11-29 16:48:10'
updated: '2019-11-29 16:50:19'
tags: [CTF, PHP安全]
permalink: /articles/2019/11/29/1575017290572.html
---
# WarmUp

> 知识点：二次url编码绕过过滤

进入页面只有一张滑稽脸（2333333），`F11`查看网页元素

![1.png](https://i.loli.net/2019/10/10/wdv5EOlkzJNmtWL.png)

根据提示访问`source.php`

![2.png](https://i.loli.net/2019/10/10/jy7ICh5cdLBPTv6.png)

`check()`函数对`file`变量进行过滤操作，然后才能包含文件。

分析`check()`函数：

1. 首先有白名单验证变量`$whitelist`。
2. `mb_substr()`和`mb_strpos()`对参数以第一次出现`？`的位置进行截取。
3. 将截取后的`$page`进行白名单验证。
4. 考虑到URL编码问题，对`$page`进行二次解码，再进行验证。

参考[phpmyadmin 4.8.1 远程文件包含漏洞（CVE-2018-12613）](https://www.cnblogs.com/leixiao-/p/10265150.html)

构造`Payload`：

```
?file=source.php%253f/../../../../../../ffffllllaaaagggg
```

![3.png](https://i.loli.net/2019/10/10/5GJS8sYDjFiyTVR.png)

浏览器解码后`payload`为`file=source.php%3f`，显然不符合白名单，二次解码后`payload`为`file=source.php?`，经过截取后符合白名单，返回`true`。

但在`include()`函数中`file=source.php%3f/..`，系统会把`source.php%3f/`看为是文件，从实现目录穿越。
